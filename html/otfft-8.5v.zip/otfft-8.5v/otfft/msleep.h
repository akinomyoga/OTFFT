/******************************************************************************
*  Copyright (c) 2015 OK Ojisan(Takuya OKAHISA)
*  Released under the MIT license
*  http://opensource.org/licenses/mit-license.php
*******************************************************************************/

#ifndef msleep_h
#define msleep_h

#include <chrono>
#if !defined(_MSC_VER) || defined(VC_THREAD)
#include <thread>

static inline void sleep(const int n)
{
    std::this_thread::sleep_for(std::chrono::seconds(n));
}

static inline void msleep(const int n)
{
    std::this_thread::sleep_for(std::chrono::milliseconds(n));
}
#else
#include <windows.h>
static inline void sleep(const int n) { Sleep(1000 * n); }
static inline void msleep(const int n) { Sleep(n); }
#endif

#endif // msleep_h
