switch (log_N) {
case  1: fft3->fwd(x, y); break;
case  2: fft3->fwd(x, y); break;
case  3: fft3->fwd(x, y); break;
case  4: fft3->fwd(x, y); break;
case  5: fft3->fwd(x, y); break;
case  6: fft1->fwd(x, y); break;
case  7: fft2->fwd(x, y); break;
case  8: fft1->fwd(x, y); break;
case  9: fft2->fwd(x, y); break;
case 10: fft1->fwd(x, y); break;
case 11: fft3->fwd(x, y); break;
case 12: fft4->fwd(x, y); break;
case 13: fft6->fwd(x, y); break;
case 14: fft6->fwd(x, y); break;
case 15: fft3->fwd(x, y); break;
case 16: fft2->fwd(x, y); break;
case 17: fft4->fwd(x, y); break;
case 18: fft5->fwd(x, y); break;
case 19: fft4->fwd(x, y); break;
case 20: fft5->fwd(x, y); break;
case 21: fft3->fwd(x, y); break;
case 22: fft5->fwd(x, y); break;
default: fft5->fwd(x, y); break;
}
