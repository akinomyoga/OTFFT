a1 = open("laptime10-fftpack.txt") { |f1| f1.readlines }
a2 = open("laptime10-ffte.txt")    { |f2| f2.readlines }
a3 = open("laptime10.txt")         { |f3| f3.readlines }
a4 = open("laptime10-mt.txt")      { |f4| f4.readlines }

puts "------+-----------+-----------------+-----------------+-----------------"
puts "length|FFTPACK[us]|     FFTE ST [us]|    ShibaFFT [us]| ShibaFFT MT [us]"
puts "------+-----------+-----------------+-----------------+-----------------"
for i in 1..7
    t1 = a1[i-1].split(/:|\[/)[1].to_f
    t2 = a2[i-1].split(/:|\[/)[1].to_f
    t3 = a3[i-1].split(/:|\[/)[1].to_f
    t4 = a4[i-1].split(/:|\[/)[1].to_f
    printf("10^(%1d)|%11.2f|%11.2f(%3d%%)|%11.2f(%3d%%)|%11.2f(%3d%%)\n",\
           i, t1, t2, 100*t2/t1, t3, 100*t3/t1, t4, 100*t4/t1)
end
puts "------+-----------+-----------------+-----------------+-----------------"
puts "FFTE ST = FFTE with Single Thread"
