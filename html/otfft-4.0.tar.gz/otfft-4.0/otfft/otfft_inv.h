switch (log_N) {
case  1: fft4->inv(x, y); break;
case  2: fft2->inv(x, y); break;
case  3: fft4->inv(x, y); break;
case  4: fft2->inv(x, y); break;
case  5: fft4->inv(x, y); break;
case  6: fft1->inv(x, y); break;
case  7: fft1->inv(x, y); break;
case  8: fft1->inv(x, y); break;
case  9: fft1->inv(x, y); break;
case 10: fft1->inv(x, y); break;
case 11: fft3->inv(x, y); break;
case 12: fft3->inv(x, y); break;
case 13: fft5->inv(x, y); break;
case 14: fft6->inv(x, y); break;
case 15: fft3->inv(x, y); break;
case 16: fft1->inv(x, y); break;
case 17: fft4->inv(x, y); break;
case 18: fft4->inv(x, y); break;
case 19: fft3->inv(x, y); break;
case 20: fft3->inv(x, y); break;
case 21: fft4->inv(x, y); break;
case 22: fft5->inv(x, y); break;
default: fft5->inv(x, y); break;
}
