/******************************************************************************
*  OTFFT Sixstep Version 8.1
*
*  Copyright (c) 2015 OK Ojisan(Takuya OKAHISA)
*  Released under the MIT license
*  http://opensource.org/licenses/mit-license.php
******************************************************************************/

#ifndef otfft_sixstep_h
#define otfft_sixstep_h

#include "otfft_misc.h"
#include "otfft_avxdif16.h"

namespace OTFFT_Sixstep { /////////////////////////////////////////////////////

using namespace OTFFT_MISC;

#ifdef DO_SINGLE_THREAD
static const int OMP_THRESHOLD1 = 1<<30;
static const int OMP_THRESHOLD2 = 1<<30;
#else
static const int OMP_THRESHOLD1 = 1<<13;
static const int OMP_THRESHOLD2 = 1<<17;
#endif

typedef const_complex_vector weight_t;
struct index_t { int row, col; };
typedef const index_t* __restrict const const_index_vector;

} /////////////////////////////////////////////////////////////////////////////

#include "otfft_sixstepsq.h"
#include "otfft_eightstep.h"

namespace OTFFT_Sixstep { /////////////////////////////////////////////////////

using namespace OTFFT_Eightstep;

struct FFT0
{
    int N, log_N;
    simd_array<complex_t> weight;
    complex_t* __restrict W;
    simd_array<complex_t> weight_sub;
    complex_t* __restrict Ws;
    simd_array<index_t> index;
    index_t* __restrict ip;

    FFT0() noexcept : N(0), log_N(0), W(0), Ws(0), ip(0) {}
    FFT0(const int n) { setup(n); }

    void setup(int n)
    {
        for (log_N = 0; n > 1; n >>= 1) log_N++;
        setup2(log_N);
    }

    inline void setup2(const int n)
    {
        log_N = n; N = 1 << n;
        weight.setup(N+1); W = &weight; init_W(N, W);
        if (n < 4) {}
        else if ((n & 1) == 1) {
            const int m = 1 << (n/2-1);
            weight_sub.setup(m+1); Ws = &weight_sub; init_W(m, Ws);
            index.setup(m/2*(m/2+1)/2); ip = &index;
            int i = 0;
            for (int k = 0; k < m; k += 2) {
                for (int p = k; p < m; p += 2) {
                    ip[i].row = k;
                    ip[i].col = p;
                    i++;
                }
            }
        }
        else {
            const int m = 1 << n/2;
            weight_sub.setup(m+1); Ws = &weight_sub; init_W(m, Ws);
            index.setup(m/2*(m/2+1)/2); ip = &index;
            int i = 0;
            for (int k = 0; k < m; k += 2) {
                for (int p = k; p < m; p += 2) {
                    ip[i].row = k;
                    ip[i].col = p;
                    i++;
                }
            }
        }
    }

    inline void fwd(complex_vector x, complex_vector y) const noexcept
    {
        static const int mode = scale_length;
        switch (log_N) {
            case  0: break;
            case  1: OTFFT_AVXDIF16::fwdfft<(1<<1),1,0,mode>()(x, y, W); break;
            case  2: OTFFT_AVXDIF16::fwdfft<(1<<2),1,0,mode>()(x, y, W); break;
            case  3: OTFFT_AVXDIF16::fwdfft<(1<<3),1,0,mode>()(x, y, W); break;
            case  4: fwdffts< 4,mode>()(ip, x, y, W, Ws); break;
            case  5: fwdfftr< 5,mode>()(ip, x, y, W, Ws); break;
            case  6: fwdffts< 6,mode>()(ip, x, y, W, Ws); break;
            case  7: fwdfftr< 7,mode>()(ip, x, y, W, Ws); break;
            case  8: fwdffts< 8,mode>()(ip, x, y, W, Ws); break;
            case  9: fwdfftr< 9,mode>()(ip, x, y, W, Ws); break;
            case 10: fwdffts<10,mode>()(ip, x, y, W, Ws); break;
            case 11: fwdfftr<11,mode>()(ip, x, y, W, Ws); break;
            case 12: fwdffts<12,mode>()(ip, x, y, W, Ws); break;
            case 13: fwdfftr<13,mode>()(ip, x, y, W, Ws); break;
            case 14: fwdffts<14,mode>()(ip, x, y, W, Ws); break;
            case 15: fwdfftr<15,mode>()(ip, x, y, W, Ws); break;
            case 16: fwdffts<16,mode>()(ip, x, y, W, Ws); break;
            case 17: fwdfftr<17,mode>()(ip, x, y, W, Ws); break;
            case 18: fwdffts<18,mode>()(ip, x, y, W, Ws); break;
            case 19: fwdfftr<19,mode>()(ip, x, y, W, Ws); break;
            case 20: fwdffts<20,mode>()(ip, x, y, W, Ws); break;
            case 21: fwdfftr<21,mode>()(ip, x, y, W, Ws); break;
            case 22: fwdffts<22,mode>()(ip, x, y, W, Ws); break;
            case 23: fwdfftr<23,mode>()(ip, x, y, W, Ws); break;
            case 24: fwdffts<24,mode>()(ip, x, y, W, Ws); break;
        }
    }

    inline void fwd0(complex_vector x, complex_vector y) const noexcept
    {
        static const int mode = scale_1;
        switch (log_N) {
            case  0: break;
            case  1: OTFFT_AVXDIF16::fwdfft<(1<<1),1,0,mode>()(x, y, W); break;
            case  2: OTFFT_AVXDIF16::fwdfft<(1<<2),1,0,mode>()(x, y, W); break;
            case  3: OTFFT_AVXDIF16::fwdfft<(1<<3),1,0,mode>()(x, y, W); break;
            case  4: fwdffts< 4,mode>()(ip, x, y, W, Ws); break;
            case  5: fwdfftr< 5,mode>()(ip, x, y, W, Ws); break;
            case  6: fwdffts< 6,mode>()(ip, x, y, W, Ws); break;
            case  7: fwdfftr< 7,mode>()(ip, x, y, W, Ws); break;
            case  8: fwdffts< 8,mode>()(ip, x, y, W, Ws); break;
            case  9: fwdfftr< 9,mode>()(ip, x, y, W, Ws); break;
            case 10: fwdffts<10,mode>()(ip, x, y, W, Ws); break;
            case 11: fwdfftr<11,mode>()(ip, x, y, W, Ws); break;
            case 12: fwdffts<12,mode>()(ip, x, y, W, Ws); break;
            case 13: fwdfftr<13,mode>()(ip, x, y, W, Ws); break;
            case 14: fwdffts<14,mode>()(ip, x, y, W, Ws); break;
            case 15: fwdfftr<15,mode>()(ip, x, y, W, Ws); break;
            case 16: fwdffts<16,mode>()(ip, x, y, W, Ws); break;
            case 17: fwdfftr<17,mode>()(ip, x, y, W, Ws); break;
            case 18: fwdffts<18,mode>()(ip, x, y, W, Ws); break;
            case 19: fwdfftr<19,mode>()(ip, x, y, W, Ws); break;
            case 20: fwdffts<20,mode>()(ip, x, y, W, Ws); break;
            case 21: fwdfftr<21,mode>()(ip, x, y, W, Ws); break;
            case 22: fwdffts<22,mode>()(ip, x, y, W, Ws); break;
            case 23: fwdfftr<23,mode>()(ip, x, y, W, Ws); break;
            case 24: fwdffts<24,mode>()(ip, x, y, W, Ws); break;
        }
    }

    inline void fwdu(complex_vector x, complex_vector y) const noexcept
    {
        static const int mode = scale_unitary;
        switch (log_N) {
            case  0: break;
            case  1: OTFFT_AVXDIF16::fwdfft<(1<<1),1,0,mode>()(x, y, W); break;
            case  2: OTFFT_AVXDIF16::fwdfft<(1<<2),1,0,mode>()(x, y, W); break;
            case  3: OTFFT_AVXDIF16::fwdfft<(1<<3),1,0,mode>()(x, y, W); break;
            case  4: fwdffts< 4,mode>()(ip, x, y, W, Ws); break;
            case  5: fwdfftr< 5,mode>()(ip, x, y, W, Ws); break;
            case  6: fwdffts< 6,mode>()(ip, x, y, W, Ws); break;
            case  7: fwdfftr< 7,mode>()(ip, x, y, W, Ws); break;
            case  8: fwdffts< 8,mode>()(ip, x, y, W, Ws); break;
            case  9: fwdfftr< 9,mode>()(ip, x, y, W, Ws); break;
            case 10: fwdffts<10,mode>()(ip, x, y, W, Ws); break;
            case 11: fwdfftr<11,mode>()(ip, x, y, W, Ws); break;
            case 12: fwdffts<12,mode>()(ip, x, y, W, Ws); break;
            case 13: fwdfftr<13,mode>()(ip, x, y, W, Ws); break;
            case 14: fwdffts<14,mode>()(ip, x, y, W, Ws); break;
            case 15: fwdfftr<15,mode>()(ip, x, y, W, Ws); break;
            case 16: fwdffts<16,mode>()(ip, x, y, W, Ws); break;
            case 17: fwdfftr<17,mode>()(ip, x, y, W, Ws); break;
            case 18: fwdffts<18,mode>()(ip, x, y, W, Ws); break;
            case 19: fwdfftr<19,mode>()(ip, x, y, W, Ws); break;
            case 20: fwdffts<20,mode>()(ip, x, y, W, Ws); break;
            case 21: fwdfftr<21,mode>()(ip, x, y, W, Ws); break;
            case 22: fwdffts<22,mode>()(ip, x, y, W, Ws); break;
            case 23: fwdfftr<23,mode>()(ip, x, y, W, Ws); break;
            case 24: fwdffts<24,mode>()(ip, x, y, W, Ws); break;
        }
    }

    inline void fwdn(complex_vector x, complex_vector y) const noexcept { fwd(x, y); }

    inline void inv(complex_vector x, complex_vector y) const noexcept
    {
        static const int mode = scale_1;
        switch (log_N) {
            case  0: break;
            case  1: OTFFT_AVXDIF16::invfft<(1<<1),1,0,mode>()(x, y, W); break;
            case  2: OTFFT_AVXDIF16::invfft<(1<<2),1,0,mode>()(x, y, W); break;
            case  3: OTFFT_AVXDIF16::invfft<(1<<3),1,0,mode>()(x, y, W); break;
            case  4: invffts< 4,mode>()(ip, x, y, W, Ws); break;
            case  5: invfftr< 5,mode>()(ip, x, y, W, Ws); break;
            case  6: invffts< 6,mode>()(ip, x, y, W, Ws); break;
            case  7: invfftr< 7,mode>()(ip, x, y, W, Ws); break;
            case  8: invffts< 8,mode>()(ip, x, y, W, Ws); break;
            case  9: invfftr< 9,mode>()(ip, x, y, W, Ws); break;
            case 10: invffts<10,mode>()(ip, x, y, W, Ws); break;
            case 11: invfftr<11,mode>()(ip, x, y, W, Ws); break;
            case 12: invffts<12,mode>()(ip, x, y, W, Ws); break;
            case 13: invfftr<13,mode>()(ip, x, y, W, Ws); break;
            case 14: invffts<14,mode>()(ip, x, y, W, Ws); break;
            case 15: invfftr<15,mode>()(ip, x, y, W, Ws); break;
            case 16: invffts<16,mode>()(ip, x, y, W, Ws); break;
            case 17: invfftr<17,mode>()(ip, x, y, W, Ws); break;
            case 18: invffts<18,mode>()(ip, x, y, W, Ws); break;
            case 19: invfftr<19,mode>()(ip, x, y, W, Ws); break;
            case 20: invffts<20,mode>()(ip, x, y, W, Ws); break;
            case 21: invfftr<21,mode>()(ip, x, y, W, Ws); break;
            case 22: invffts<22,mode>()(ip, x, y, W, Ws); break;
            case 23: invfftr<23,mode>()(ip, x, y, W, Ws); break;
            case 24: invffts<24,mode>()(ip, x, y, W, Ws); break;
        }
    }

    inline void inv0(complex_vector x, complex_vector y) const noexcept { inv(x, y); }

    inline void invu(complex_vector x, complex_vector y) const noexcept
    {
        static const int mode = scale_unitary;
        switch (log_N) {
            case  0: break;
            case  1: OTFFT_AVXDIF16::invfft<(1<<1),1,0,mode>()(x, y, W); break;
            case  2: OTFFT_AVXDIF16::invfft<(1<<2),1,0,mode>()(x, y, W); break;
            case  3: OTFFT_AVXDIF16::invfft<(1<<3),1,0,mode>()(x, y, W); break;
            case  4: invffts< 4,mode>()(ip, x, y, W, Ws); break;
            case  5: invfftr< 5,mode>()(ip, x, y, W, Ws); break;
            case  6: invffts< 6,mode>()(ip, x, y, W, Ws); break;
            case  7: invfftr< 7,mode>()(ip, x, y, W, Ws); break;
            case  8: invffts< 8,mode>()(ip, x, y, W, Ws); break;
            case  9: invfftr< 9,mode>()(ip, x, y, W, Ws); break;
            case 10: invffts<10,mode>()(ip, x, y, W, Ws); break;
            case 11: invfftr<11,mode>()(ip, x, y, W, Ws); break;
            case 12: invffts<12,mode>()(ip, x, y, W, Ws); break;
            case 13: invfftr<13,mode>()(ip, x, y, W, Ws); break;
            case 14: invffts<14,mode>()(ip, x, y, W, Ws); break;
            case 15: invfftr<15,mode>()(ip, x, y, W, Ws); break;
            case 16: invffts<16,mode>()(ip, x, y, W, Ws); break;
            case 17: invfftr<17,mode>()(ip, x, y, W, Ws); break;
            case 18: invffts<18,mode>()(ip, x, y, W, Ws); break;
            case 19: invfftr<19,mode>()(ip, x, y, W, Ws); break;
            case 20: invffts<20,mode>()(ip, x, y, W, Ws); break;
            case 21: invfftr<21,mode>()(ip, x, y, W, Ws); break;
            case 22: invffts<22,mode>()(ip, x, y, W, Ws); break;
            case 23: invfftr<23,mode>()(ip, x, y, W, Ws); break;
            case 24: invffts<24,mode>()(ip, x, y, W, Ws); break;
        }
    }

    inline void invn(complex_vector x, complex_vector y) const noexcept
    {
        static const int mode = scale_length;
        switch (log_N) {
            case  0: break;
            case  1: OTFFT_AVXDIF16::invfft<(1<<1),1,0,mode>()(x, y, W); break;
            case  2: OTFFT_AVXDIF16::invfft<(1<<2),1,0,mode>()(x, y, W); break;
            case  3: OTFFT_AVXDIF16::invfft<(1<<3),1,0,mode>()(x, y, W); break;
            case  4: invffts< 4,mode>()(ip, x, y, W, Ws); break;
            case  5: invfftr< 5,mode>()(ip, x, y, W, Ws); break;
            case  6: invffts< 6,mode>()(ip, x, y, W, Ws); break;
            case  7: invfftr< 7,mode>()(ip, x, y, W, Ws); break;
            case  8: invffts< 8,mode>()(ip, x, y, W, Ws); break;
            case  9: invfftr< 9,mode>()(ip, x, y, W, Ws); break;
            case 10: invffts<10,mode>()(ip, x, y, W, Ws); break;
            case 11: invfftr<11,mode>()(ip, x, y, W, Ws); break;
            case 12: invffts<12,mode>()(ip, x, y, W, Ws); break;
            case 13: invfftr<13,mode>()(ip, x, y, W, Ws); break;
            case 14: invffts<14,mode>()(ip, x, y, W, Ws); break;
            case 15: invfftr<15,mode>()(ip, x, y, W, Ws); break;
            case 16: invffts<16,mode>()(ip, x, y, W, Ws); break;
            case 17: invfftr<17,mode>()(ip, x, y, W, Ws); break;
            case 18: invffts<18,mode>()(ip, x, y, W, Ws); break;
            case 19: invfftr<19,mode>()(ip, x, y, W, Ws); break;
            case 20: invffts<20,mode>()(ip, x, y, W, Ws); break;
            case 21: invfftr<21,mode>()(ip, x, y, W, Ws); break;
            case 22: invffts<22,mode>()(ip, x, y, W, Ws); break;
            case 23: invfftr<23,mode>()(ip, x, y, W, Ws); break;
            case 24: invffts<24,mode>()(ip, x, y, W, Ws); break;
        }
    }
};

#if 0
struct FFT
{
    FFT0 fft;
    simd_array<complex_t> work;
    complex_t* y;

    FFT() : fft(), work(), y(0) {}
    FFT(int n) : fft(n), work(n), y(&work) {}

    inline void setup(const int n) { fft.setup(n); work.setup(n); y = &work; }

    inline void fwd(complex_vector  x) const noexcept { fft.fwd(x, y);  }
    inline void fwd0(complex_vector x) const noexcept { fft.fwd0(x, y); }
    inline void fwdu(complex_vector x) const noexcept { fft.fwdu(x, y); }
    inline void fwdn(complex_vector x) const noexcept { fft.fwdn(x, y); }
    inline void inv(complex_vector  x) const noexcept { fft.inv(x, y);  }
    inline void inv0(complex_vector x) const noexcept { fft.inv0(x, y); }
    inline void invu(complex_vector x) const noexcept { fft.invu(x, y); }
    inline void invn(complex_vector x) const noexcept { fft.invn(x, y); }
};
#endif

} /////////////////////////////////////////////////////////////////////////////

#endif // otfft_sixstep_h
