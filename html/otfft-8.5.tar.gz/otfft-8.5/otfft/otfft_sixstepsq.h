/******************************************************************************
*  OTFFT Sixstep of Square Version 8.5
*
*  Copyright (c) 2015 OK Ojisan(Takuya OKAHISA)
*  Released under the MIT license
*  http://opensource.org/licenses/mit-license.php
******************************************************************************/

#ifndef otfft_sixstepsq_h
#define otfft_sixstepsq_h

#include "otfft_avxdif16.h"

namespace OTFFT_Sixstep { /////////////////////////////////////////////////////

#ifdef DO_SINGLE_THREAD
static const int OMP_THRESHOLD1 = 1<<30;
static const int OMP_THRESHOLD2 = 1<<30;
#else
static const int OMP_THRESHOLD1 = 1<<13;
static const int OMP_THRESHOLD2 = 1<<17;
#endif

template <int log_N, int s, int mode> struct fwdffts_body
{
    static const int log_n = log_N/2;
    static const int N = 1 << log_N;
    static const int n = 1 << log_n;
    static const int m = n/2*(n/2+1)/2;

    static void transpose_kernel(const int k, const int p, complex_vector x) NOEXCEPT
    {
        if (k == p) {
            const int k_kn = k + k*n;
            const ymm aA = getpz2(x+k_kn+0);
            const ymm bB = getpz2(x+k_kn+n);
            const ymm ab = catlo(aA, bB);
            const ymm AB = cathi(aA, bB);
            setpz2(x+k_kn+0, ab);
            setpz2(x+k_kn+n, AB);
        }
        else {
            const int p_kn = p + k*n;
            const int k_pn = k + p*n;
            const ymm aA = getpz2(x+p_kn+0);
            const ymm bB = getpz2(x+p_kn+n);
            const ymm cC = getpz2(x+k_pn+0);
            const ymm dD = getpz2(x+k_pn+n);
            const ymm ab = catlo(aA, bB);
            const ymm AB = cathi(aA, bB);
            const ymm cd = catlo(cC, dD);
            const ymm CD = cathi(cC, dD);
            setpz2(x+k_pn+0, ab);
            setpz2(x+k_pn+n, AB);
            setpz2(x+p_kn+0, cd);
            setpz2(x+p_kn+n, CD);
        }
    }

    static void mult_twiddle_factor_kernel(
            const int p, const int k, complex_vector x, weight_t W) NOEXCEPT
    {
        if (p == k) {
            const int pp = p*p;
            complex_vector x_p_pn = x + p + p*n;
            const complex_t& w = W[s*(pp+p)];
            const ymm w1 = scalepz2<N,mode>(cmplx2(W[s*(pp)], w));
            const ymm w2 = scalepz2<N,mode>(cmplx2(w, W[s*(pp+2*p+1)]));
            const ymm aA = mulpz2(w1, getpz2(x_p_pn+0));
            const ymm bB = mulpz2(w2, getpz2(x_p_pn+n));
            const ymm ab = catlo(aA, bB);
            const ymm AB = cathi(aA, bB);
            setpz2(x_p_pn+0, ab);
            setpz2(x_p_pn+n, AB);
        }
        else {
            const int kp = k*p;
            complex_vector x_k_pn = x + k + p*n;
            complex_vector x_p_kn = x + p + k*n;
            const ymm w1 = scalepz2<N,mode>(cmplx2(W[s*(kp)],   W[s*(kp+p)]));
            const ymm w2 = scalepz2<N,mode>(cmplx2(W[s*(kp+k)], W[s*(kp+k+p+1)]));
            const ymm aA = mulpz2(w1, getpz2(x_k_pn+0));
            const ymm bB = mulpz2(w2, getpz2(x_k_pn+n));
            const ymm cC = getpz2(x_p_kn+0);
            const ymm dD = getpz2(x_p_kn+n);
            const ymm ab = catlo(aA, bB);
            const ymm AB = cathi(aA, bB);
            const ymm cd = mulpz2(w1, catlo(cC, dD));
            const ymm CD = mulpz2(w2, cathi(cC, dD));
            setpz2(x_p_kn+0, ab);
            setpz2(x_p_kn+n, AB);
            setpz2(x_k_pn+0, cd);
            setpz2(x_k_pn+n, CD);
        }
    }

    void operator()(const_index_vector ip,
            complex_vector x, complex_vector y, weight_t W, weight_t Ws) const NOEXCEPT
    {
        if (N < OMP_THRESHOLD1) {
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                OTFFT_AVXDIF16::fwdfft<n,1,0,scale_1>()(x + pn, y + pn, Ws);
            }
            for (int i = 0; i < m; i++) {
                const int p = ip[i].row;
                const int k = ip[i].col;
                mult_twiddle_factor_kernel(p, k, x, W);
            }
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                OTFFT_AVXDIF16::fwdfft<n,1,0,scale_1>()(x + kn, y + kn, Ws);
            }
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
        }
        else if (N < OMP_THRESHOLD2) //////////////////////////////////////////
        #pragma omp parallel firstprivate(ip,x,y,W,Ws)
        {
            #pragma omp for schedule(static)
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
            #pragma omp for schedule(static)
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                OTFFT_AVXDIF16::fwdfft<n,1,0,scale_1>()(x + pn, y + pn, Ws);
            }
            #pragma omp for schedule(static)
            for (int i = 0; i < m; i++) {
                const int p = ip[i].row;
                const int k = ip[i].col;
                mult_twiddle_factor_kernel(p, k, x, W);
            }
            #pragma omp for schedule(static)
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                OTFFT_AVXDIF16::fwdfft<n,1,0,scale_1>()(x + kn, y + kn, Ws);
            }
            #pragma omp for schedule(static) nowait
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
        }
        else //////////////////////////////////////////////////////////////////
        #pragma omp parallel firstprivate(ip,x,y,W,Ws)
        {
            #pragma omp for schedule(guided)
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
            #pragma omp for schedule(guided)
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                OTFFT_AVXDIF16::fwdfft<n,1,0,scale_1>()(x + pn, y + pn, Ws);
            }
            #pragma omp for schedule(guided)
            for (int i = 0; i < m; i++) {
                const int p = ip[i].row;
                const int k = ip[i].col;
                mult_twiddle_factor_kernel(p, k, x, W);
            }
            #pragma omp for schedule(guided)
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                OTFFT_AVXDIF16::fwdfft<n,1,0,scale_1>()(x + kn, y + kn, Ws);
            }
            #pragma omp for schedule(guided) nowait
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
        }
    }
};

template <int log_N, int mode> struct fwdffts
{
    inline void operator()(const_index_vector ip,
            complex_vector x, complex_vector y, weight_t W, weight_t Ws) const NOEXCEPT
    {
        fwdffts_body<log_N,1,mode>()(ip, x, y, W, Ws);
    }
};

template <int log_N, int mode> struct fwdffts2
{
    inline void operator()(const_index_vector ip,
            complex_vector x, complex_vector y, weight_t W, weight_t Ws) const NOEXCEPT
    {
        fwdffts_body<log_N,2,mode>()(ip, x, y, W, Ws);
    }
};

template <int log_N, int mode> struct fwdffts8
{
    inline void operator()(const_index_vector ip,
            complex_vector x, complex_vector y, weight_t W, weight_t Ws) const NOEXCEPT
    {
        fwdffts_body<log_N,8,mode>()(ip, x, y, W, Ws);
    }
};

///////////////////////////////////////////////////////////////////////////////

template <int log_N, int s, int mode> struct invffts_body
{
    static const int log_n = log_N/2;
    static const int N = 1 << log_N;
    static const int n = 1 << log_n;
    static const int m = n/2*(n/2+1)/2;
    
    static inline void transpose_kernel(
            const int k, const int p, complex_vector x) NOEXCEPT
    {
        fwdffts_body<log_N,s,mode>::transpose_kernel(k, p, x);
    }

    static void mult_twiddle_factor_kernel(
            const int p, const int k, complex_vector x, weight_t W) NOEXCEPT
    {
        if (p == k) {
            const int M = N-p*p;
            complex_vector x_p_pn = x + p + p*n;
            const complex_t& w = W[s*(M-p)];
            const ymm w1 = scalepz2<N,mode>(cmplx2(W[s*(M)], w));
            const ymm w2 = scalepz2<N,mode>(cmplx2(w, W[s*(M-2*p-1)]));
            const ymm aA = mulpz2(w1, getpz2(x_p_pn+0));
            const ymm bB = mulpz2(w2, getpz2(x_p_pn+n));
            const ymm ab = catlo(aA, bB);
            const ymm AB = cathi(aA, bB);
            setpz2(x_p_pn+0, ab);
            setpz2(x_p_pn+n, AB);
        }
        else {
            const int M = N-k*p;
            complex_vector x_k_pn = x + k + p*n;
            complex_vector x_p_kn = x + p + k*n;
            const ymm w1 = scalepz2<N,mode>(cmplx2(W[s*(M)],   W[s*(M-p)]));
            const ymm w2 = scalepz2<N,mode>(cmplx2(W[s*(M-k)], W[s*(M-k-p-1)]));
            const ymm aA = mulpz2(w1, getpz2(x_k_pn+0));
            const ymm bB = mulpz2(w2, getpz2(x_k_pn+n));
            const ymm cC = getpz2(x_p_kn+0);
            const ymm dD = getpz2(x_p_kn+n);
            const ymm ab = catlo(aA, bB);
            const ymm AB = cathi(aA, bB);
            const ymm cd = mulpz2(w1, catlo(cC, dD));
            const ymm CD = mulpz2(w2, cathi(cC, dD));
            setpz2(x_p_kn+0, ab);
            setpz2(x_p_kn+n, AB);
            setpz2(x_k_pn+0, cd);
            setpz2(x_k_pn+n, CD);
        }
    }

    void operator()(const_index_vector ip,
            complex_vector x, complex_vector y, weight_t W, weight_t Ws) const NOEXCEPT
    {
        if (N < OMP_THRESHOLD1) {
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                OTFFT_AVXDIF16::invfft<n,1,0,scale_1>()(x + pn, y + pn, Ws);
            }
            for (int i = 0; i < m; i++) {
                const int p = ip[i].row;
                const int k = ip[i].col;
                mult_twiddle_factor_kernel(p, k, x, W);
            }
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                OTFFT_AVXDIF16::invfft<n,1,0,scale_1>()(x + kn, y + kn, Ws);
            }
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
        }
        else if (N < OMP_THRESHOLD2) //////////////////////////////////////////
        #pragma omp parallel firstprivate(ip,x,y,W,Ws)
        {
            #pragma omp for schedule(static)
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
            #pragma omp for schedule(static)
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                OTFFT_AVXDIF16::invfft<n,1,0,scale_1>()(x + pn, y + pn, Ws);
            }
            #pragma omp for schedule(static)
            for (int i = 0; i < m; i++) {
                const int p = ip[i].row;
                const int k = ip[i].col;
                mult_twiddle_factor_kernel(p, k, x, W);
            }
            #pragma omp for schedule(static)
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                OTFFT_AVXDIF16::invfft<n,1,0,scale_1>()(x + kn, y + kn, Ws);
            }
            #pragma omp for schedule(static) nowait
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
        }
        else //////////////////////////////////////////////////////////////////
        #pragma omp parallel firstprivate(ip,x,y,W,Ws)
        {
            #pragma omp for schedule(guided)
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
            #pragma omp for schedule(guided)
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                OTFFT_AVXDIF16::invfft<n,1,0,scale_1>()(x + pn, y + pn, Ws);
            }
            #pragma omp for schedule(guided)
            for (int i = 0; i < m; i++) {
                const int p = ip[i].row;
                const int k = ip[i].col;
                mult_twiddle_factor_kernel(p, k, x, W);
            }
            #pragma omp for schedule(guided)
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                OTFFT_AVXDIF16::invfft<n,1,0,scale_1>()(x + kn, y + kn, Ws);
            }
            #pragma omp for schedule(guided) nowait
            for (int i = 0; i < m; i++) {
                const int k = ip[i].row;
                const int p = ip[i].col;
                transpose_kernel(k, p, x);
            }
        }
    }
};

template <int log_N, int mode> struct invffts
{
    inline void operator()(const_index_vector ip,
            complex_vector x, complex_vector y, weight_t W, weight_t Ws) const NOEXCEPT
    {
        invffts_body<log_N,1,mode>()(ip, x, y, W, Ws);
    }
};

template <int log_N, int mode> struct invffts2
{
    inline void operator()(const_index_vector ip,
            complex_vector x, complex_vector y, weight_t W, weight_t Ws) const NOEXCEPT
    {
        invffts_body<log_N,2,mode>()(ip, x, y, W, Ws);
    }
};

template <int log_N, int mode> struct invffts8
{
    inline void operator()(const_index_vector ip,
            complex_vector x, complex_vector y, weight_t W, weight_t Ws) const NOEXCEPT
    {
        invffts_body<log_N,8,mode>()(ip, x, y, W, Ws);
    }
};

} /////////////////////////////////////////////////////////////////////////////

#endif // otfft_sixstepsq_h
