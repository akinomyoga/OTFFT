This software is released under the MIT License, see LICENSE.txt.

このソフトウェアは MIT ライセンスのもとにリリースされています。
詳細は LICENSE.txt を見てください。

-------------------------------------------------------------------------------

【Visual Studio Solution 版 OTFFT の使い方】

STEP-1. ffttune プロジェクトをビルドしてください。
STEP-2. Visual Studio から ffttune を実行してください。
STEP-3. otfft プロジェクトをビルドしてください。
STEP-4. サンプルプログラム(fftbench プロジェクト)をビルドしてください。
STEP-5. fftbench を実行してください。
STEP-6. あとはご自由にお楽しみください！

-------------------------------------------------------------------------------

　以下で、サポートされる変換を説明します。変換する系列長 N は 2^30 (2の30乗)より
小さい必要がありますが、2^30 より小さくても、計算機のメモリが足りなくなれば変換
できません。


【複素離散フーリエ変換】

　系列長 N の複素離散フーリエ変換を実行するには、

    #include "otfft/otfft.h"
    using OTFFT::complex_t;
    using OTFFT::simd_malloc;
    using OTFFT::simd_free;

    void f(int N)
    {
        complex_t* x = (complex_t*) simd_malloc(N*sizeof(complex_t));
        // 何かする...
        OTFFT::FFT fft(N); // FFT オブジェクトの作成(スレッドプール起動)
        fft.fwd(x);        // 複素離散フーリエ変換を実行。x が入力かつ出力
        fft.stop();        // スレッドプール停止
        // 何かする...
        simd_free(x);
    }

のようにします。ただし、N の素因数が小さな素数にならない場合は、計算量が O(N^2)
になります。

　OTFFT はデフォルトではマルチスレッドで動作します。FFT オブジェクトの作成と
同時にスレッドプールを起動します。FFT/IFFT が終わったら速やかにスレッドプール
を停止する必要があります。そうしないと、他のスレッドの邪魔をしてしまいます。
逆に、何度も FFT/IFFT を繰り返す場合は、その間スレッドプールを停止すべきでは
ありません。

　明示的にスレッドプールを停止しなくとも、FFT オブジェクトが破棄されるときに
スレッドプールは停止されますので、FFT/IFFT の後、すぐに FFT オブジェクトを破棄
する場合は、明示的にスレッドプールを停止する必要はありません。

　また、スレッドプールを停止した状態で FFT/IFFT を実行すると、自動的にスレッド
プールが起動されますので、FFT/IFFT 以外の計算に CPU パワーを集中させたい場合は、
積極的にスレッドプールを停止した方がよいかもしれません。しかし、スレッドプール
の起動と停止の繰り返しにはそれなりのコストがかかるので、どちらを優先するか
バランスをとる必要があります。

complex_t は

    struct complex_t
    {
        double Re, Im;

        complex_t() : Re(0), Im(0) {}
        complex_t(const double& x) : Re(x), Im(0) {}
        complex_t(const double& x, const double& y) : Re(x), Im(y) {}
        complex_t(const std::complex<double>& z) : Re(z.real()), Im(z.imag()) {}
        operator std::complex<double>() const { return std::complex<double>(Re, Im); }

        // その他のメンバ関数...
    };

のように定義されています。

　フーリエ変換(fwd)には係数 1/N が掛かっています。もしそれが不都合なら係数の
掛かっていない(fwd0)もあります。以下のようなメンバ関数が用意されています。

    fwd(x)  離散フーリエ変換(1/N による正規化付き)
    fwd0(x) 離散フーリエ変換(正規化無し)
    fwdu(x) 離散フーリエ変換(ユニタリ変換。つまり sqrt(1/N) で正規化)
    fwdn(x) 離散フーリエ変換(1/N による正規化付き)

    inv(x)  逆離散フーリエ変換(正規化無し)
    inv0(x) 逆離散フーリエ変換(正規化無し)
    invu(x) 逆離散フーリエ変換(ユニタリ変換)
    invn(x) 逆離散フーリエ変換(1/N による正規化付き)

FFT の系列長を変更したい場合は、

    fft.setup(2 * N);

のようにします。

　OTFFT は Stockham のアルゴリズムを使っていますので、実行には入力系列と
同じ系列長の作業領域が必要です。普通は内部でその領域を確保しますが、
マルチスレッドのプログラムを組む場合など、それだと都合が悪い場合があります。
そんな時は外部から作業領域を渡すバージョンもあります。次のように使います。
ただし、OTFFT をシングルスレッドモードでビルドしたとします。

    #include "otfft/otfft.h"
    using OTFFT::complex_t;
    using OTFFT::simd_malloc;
    using OTFFT::simd_free;

    void f(int N)
    {
        complex_t* x = (complex_t*) simd_malloc(N*sizeof(complex_t));
        complex_t* y = (complex_t*) simd_malloc(N*sizeof(complex_t));
        // 何かする...
        OTFFT::FFT0 fft(N);
        fft.fwd(x, y);      // x が入力かつ出力、y が作業領域
        // 何かする...
        fft.inv(x, y);      // x が入力かつ出力、y が作業領域
        // 何かする...
        simd_free(y);
        simd_free(x);
    }

　OTFFT::FFT だったところが OTFFT::FFT0 になっていることに注意してください。


【実離散フーリエ変換】

　実離散フーリエ変換では、系列長 N は４の倍数である必要があります。系列長 N の
実離散フーリエ変換を実行するには以下のようにします。

    #include "otfft/otfft.h"
    using OTFFT::complex_t;
    using OTFFT::simd_malloc;
    using OTFFT::simd_free;

    void f(int N)
    {
        double*    x = (double*)    simd_malloc(N*sizeof(double));
        complex_t* y = (complex_t*) simd_malloc(N*sizeof(complex_t));
        // 何かする...
        OTFFT::RFFT rfft(N);
        rfft.fwd(x, y); // 実離散フーリエ変換を実行。x が入力、y が出力
        rfft.stop();
        // 何かする...
        simd_free(y);
        simd_free(x);
    }

ただし、N の素因数が小さな素数にならない場合は、計算量が O(N^2) になります。

　実離散フーリエ変換には以下のようなメンバ関数が用意されています。

    fwd(x, y)  実離散フーリエ変換(1/N による正規化付き) x:入力、y:出力
    fwd0(x, y) 実離散フーリエ変換(正規化無し)           x:入力、y:出力
    fwdu(x, y) 実離散フーリエ変換(ユニタリ変換)         x:入力、y:出力
    fwdn(x, y) 実離散フーリエ変換(1/N による正規化付き) x:入力、y:出力

    inv(y, x)  逆実離散フーリエ変換(正規化無し)           y:入力、x:出力
    inv0(y, x) 逆実離散フーリエ変換(正規化無し)           y:入力、x:出力
    invu(y, x) 逆実離散フーリエ変換(ユニタリ変換)         y:入力、x:出力
    invn(y, x) 逆実離散フーリエ変換(1/N による正規化付き) y:入力、x:出力

　逆実離散フーリエ変換は複素系列 y を受け取って、実系列 x を返します。
y が y[N-k] == conj(y[k]) でないと正しい結果を返しません。また、
逆実離散フーリエ変換は入力 y を破壊します。保存しておきたい場合は、
コピーを取っておく必要があります。内部的には系列長 N/2 の複素離散フーリエ変換
で実装されています。

　実離散フーリエ変換は、作業領域として出力系列を使います。そして逆実離散フーリエ
変換は、作業領域として入力系列を使います。マルチスレッドでプログラムする場合も、
それぞれのスレッド専用の入力と出力を与えてやれば OK です。


【離散コサイン変換(DCT-II)】

　離散コサイン変換では、系列長 N は偶数である必要があります。系列長 N の
離散コサイン変換(DCT-II)を実行するには以下のようにします。

    #include "otfft/otfft.h"
    using OTFFT::complex_t;
    using OTFFT::simd_malloc;
    using OTFFT::simd_free;

    void f(int N)
    {
        double* x = (double*) simd_malloc(N*sizeof(double));
        // 何かする...
        OTFFT::DCT dct(N);
        dct.fwd(x); // DCT-II を実行する。x が入力かつ出力
        // 何かする...
        dct.inv(x); // IDCT-II を実行する。x が入力かつ出力
        dct.stop();
        // 何かする...
        simd_free(x);
    }

ただし、N の素因数が小さな素数にならない場合は、計算量が O(N^2) になります。

　離散コサイン変換には以下のようなメンバ関数が用意されています。

    fwd(x)  離散コサイン変換(1/N による正規化付き)
    fwd0(x) 離散コサイン変換(正規化無し)
    fwdn(x) 離散コサイン変換(1/N による正規化付き)

    inv(x)  逆離散コサイン変換(正規化無し)
    inv0(x) 逆離散コサイン変換(正規化無し)
    invn(x) 逆離散コサイン変換(1/N による正規化付き)

　離散コサイン変換は DCT-II を採用しています。ただし、直交化はしていません。
内部的には系列長 N/2 の複素離散フーリエ変換で実装されています。マルチスレッドで
使う場合、作業領域を外部から与えるバージョンもあります。以下のように使います。
ただし、OTFFT をシングルスレッドモードでビルドしたとします。

    #include "otfft/otfft.h"
    using OTFFT::complex_t;
    using OTFFT::simd_malloc;
    using OTFFT::simd_free;

    void f(int N)
    {
        double*    x = (double*)    simd_malloc(N*sizeof(double));
        double*    y = (double*)    simd_malloc(N*sizeof(double));
        complex_t* z = (complex_t*) simd_malloc(N*sizeof(complex_t));
        // 何かする...
        OTFFT::DCT0 dct(N);
        dct.fwd(x, y, z); // DCT を実行する。x が入力かつ出力、y,z が作業領域
        // 何かする...
        dct.inv(x, y, z); // 逆DCT を実行する。x が入力かつ出力、y,z が作業領域
        // 何かする...
        simd_free(z);
        simd_free(y);
        simd_free(x);
    }

　OTFFT::DCT だったところが OTFFT::DCT0 になっていることに注意してください。


【Bluestein's FFT】

　系列長 N の Bluestein's FFT(任意の系列長の FFT) を実行するには以下のように
します。

    #include "otfft/otfft.h"
    using OTFFT::complex_t;
    using OTFFT::simd_malloc;
    using OTFFT::simd_free;

    void f(int N)
    {
        complex_t* x = (complex_t*) simd_malloc(N*sizeof(complex_t));
        // 何かする...
        OTFFT::Bluestein bst(N); // N は 2^28 以下の任意の自然数。
        bst.fwd(x); // Bluestein's FFT を実行する。x が入力かつ出力
        // 何かする...
        bst.inv(x); // Bluestein's IFFT を実行する。x が入力かつ出力
        bst.stop();
        // 何かする...
        simd_free(x);
    }

　Bluestein's FFT では離散フーリエ変換の系列長が小さな素因数に分解できる必要は
ありません。例えば系列長が大きな素数でも計算量は O(N log N) になります。
他の変換では、N が小さな素因数に分解できない場合は計算量が O(N^2) になります。
指定出来る系列長の上限は 2^28 です。もちろん、メモリが足りなくなれば、それより
小さい系列長でも変換できません。マルチスレッド用のメンバ関数は用意されて
いません。どうしてもマルチスレッドで使いたい場合は、動作確認はしていませんが、
スレッドの数だけ Bluestein オブジェクトを生成し、各スレッドでそれらを使い
分ければ大丈夫と思います。当然、メモリをゴージャスに使ってしまいます。

　Bluestein's FFT には以下のようなメンバ関数が用意されています。

    fwd(x)  離散フーリエ変換(1/N による正規化付き)
    fwd0(x) 離散フーリエ変換(正規化無し)
    fwdu(x) 離散フーリエ変換(ユニタリ変換)
    fwdn(x) 離散フーリエ変換(1/N による正規化付き)

    inv(x)  逆離散フーリエ変換(正規化無し)
    inv0(x) 逆離散フーリエ変換(正規化無し)
    invu(x) 逆離散フーリエ変換(ユニタリ変換)
    invn(x) 逆離散フーリエ変換(1/N による正規化付き)
