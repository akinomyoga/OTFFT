/******************************************************************************
*  OTFFT Sixstep Version 5.2
******************************************************************************/

#ifndef otfft_sixstep_h
#define otfft_sixstep_h

#include <utility>

#include "otfft_misc.h"
#include "otfft_avxdifx.h"

namespace OTFFT_Sixstep { /////////////////////////////////////////////////////

using namespace OTFFT_MISC;

static const int OMP_THRESHOLD1 = 1<<13;
static const int OMP_THRESHOLD2 = 1<<17;

} /////////////////////////////////////////////////////////////////////////////

#include "otfft_sixstep0r.h"
#include "otfft_sixstep0s.h"
#include "otfft_sixstepnr.h"
#include "otfft_sixstepns.h"

namespace OTFFT_Sixstep { /////////////////////////////////////////////////////

template <int log_N> struct fwd0fftq
{
    static const int N = 1 << log_N;
    static const int N0 = 0;
    static const int N1 = N/8;
    static const int N2 = N/4;
    static const int N3 = N1 + N2;
    static const int N4 = N/2;
    static const int N5 = N2 + N3;
    static const int N6 = N3 + N3;
    static const int N7 = N3 + N4;

    static inline void transpose_kernel(
            const int p, complex_vector x, complex_vector y)
    {
        const ymm ab = getpz2(x+p+N0);
        const ymm cd = getpz2(x+p+N1);
        const ymm ef = getpz2(x+p+N2);
        const ymm gh = getpz2(x+p+N3);
        const ymm ij = getpz2(x+p+N4);
        const ymm kl = getpz2(x+p+N5);
        const ymm mn = getpz2(x+p+N6);
        const ymm op = getpz2(x+p+N7);
        const ymm ac = catlo(ab, cd);
        const ymm bd = cathi(ab, cd);
        const ymm eg = catlo(ef, gh);
        const ymm fh = cathi(ef, gh);
        const ymm ik = catlo(ij, kl);
        const ymm jl = cathi(ij, kl);
        const ymm mo = catlo(mn, op);
        const ymm np = cathi(mn, op);
        setpz2(y+8*p+ 0, ac);
        setpz2(y+8*p+ 2, eg);
        setpz2(y+8*p+ 4, ik);
        setpz2(y+8*p+ 6, mo);
        setpz2(y+8*p+ 8, bd);
        setpz2(y+8*p+10, fh);
        setpz2(y+8*p+12, jl);
        setpz2(y+8*p+14, np);
    }

    static inline void mult_twiddle_factor_kernel(const int p,
            complex_vector x, complex_vector y, const_complex_vector W)
    {
        const ymm w1p = getpz2(W+p);
        const ymm w2p = mulpz2(w1p, w1p);
        const ymm w3p = mulpz2(w1p, w2p);
        const ymm w4p = mulpz2(w2p, w2p);
        const ymm w5p = mulpz2(w2p, w3p);
        const ymm w6p = mulpz2(w3p, w3p);
        const ymm w7p = mulpz2(w3p, w4p);
        const ymm a = getpz2(x+p+N0);
        const ymm b = getpz2(x+p+N1);
        const ymm c = getpz2(x+p+N2);
        const ymm d = getpz2(x+p+N3);
        const ymm e = getpz2(x+p+N4);
        const ymm f = getpz2(x+p+N5);
        const ymm g = getpz2(x+p+N6);
        const ymm h = getpz2(x+p+N7);
        const ymm jc = jxpz2(c);
        const ymm jd = jxpz2(d);
        const ymm jg = jxpz2(g);
        const ymm jh = jxpz2(h);
        const ymm ap1c = addpz2(a,  c);
        const ymm amjc = subpz2(a, jc);
        const ymm am1c = subpz2(a,  c);
        const ymm apjc = addpz2(a, jc);
        const ymm bp1d = addpz2(b,  d);
        const ymm bmjd = subpz2(b, jd);
        const ymm bm1d = subpz2(b,  d);
        const ymm bpjd = addpz2(b, jd);
        const ymm ep1g = addpz2(e,  g);
        const ymm emjg = subpz2(e, jg);
        const ymm em1g = subpz2(e,  g);
        const ymm epjg = addpz2(e, jg);
        const ymm fp1h = addpz2(f,  h);
        const ymm fmjh = subpz2(f, jh);
        const ymm fm1h = subpz2(f,  h);
        const ymm fpjh = addpz2(f, jh);
        const ymm   ap1c_p_ep1g =        addpz2(ap1c, ep1g);
        const ymm   bp1d_p_fp1h =        addpz2(bp1d, fp1h);
        const ymm   amjc_m_emjg =        subpz2(amjc, emjg);
        const ymm w8bmjd_m_fmjh = w8xpz2(subpz2(bmjd, fmjh));
        const ymm   am1c_p_em1g =        addpz2(am1c, em1g);
        const ymm jxbm1d_p_fm1h =  jxpz2(addpz2(bm1d, fm1h));
        const ymm   apjc_m_epjg =        subpz2(apjc, epjg);
        const ymm v8bpjd_m_fpjh = v8xpz2(subpz2(bpjd, fpjh));
        setpz2(y+p+N0,             addpz2(ap1c_p_ep1g,   bp1d_p_fp1h));
        setpz2(y+p+N1, mulpz2(w1p, addpz2(amjc_m_emjg, w8bmjd_m_fmjh)));
        setpz2(y+p+N2, mulpz2(w2p, subpz2(am1c_p_em1g, jxbm1d_p_fm1h)));
        setpz2(y+p+N3, mulpz2(w3p, subpz2(apjc_m_epjg, v8bpjd_m_fpjh)));
        setpz2(y+p+N4, mulpz2(w4p, subpz2(ap1c_p_ep1g,   bp1d_p_fp1h)));
        setpz2(y+p+N5, mulpz2(w5p, subpz2(amjc_m_emjg, w8bmjd_m_fmjh)));
        setpz2(y+p+N6, mulpz2(w6p, addpz2(am1c_p_em1g, jxbm1d_p_fm1h)));
        setpz2(y+p+N7, mulpz2(w7p, addpz2(apjc_m_epjg, v8bpjd_m_fpjh)));
    }

    template <typename fft_t>
    void operator()(const fft_t& fft,
            complex_vector x, complex_vector y, const_complex_vector W) const
    {
        if (N < OMP_THRESHOLD1) {
            for (int p = 0; p < N1; p += 2) {
                /*
                const ymm wp = getpz2(W+p);
                const ymm a  = getpz2(x+p+0);
                const ymm b  = getpz2(x+p+m);
                setpz2(y+p+0,            addpz2(a, b));
                setpz2(y+p+m, mulpz2(wp, subpz2(a, b)));
                */
                mult_twiddle_factor_kernel(p, x, y, W);
            }
            //fwd0ffts2<log_N-1>()(fft, y+0, x+0, W);
            //fwd0ffts2<log_N-1>()(fft, y+m, x+m, W);
            fwd0ffts8<log_N-3>()(fft, y+N0, x+N0, W);
            fwd0ffts8<log_N-3>()(fft, y+N1, x+N1, W);
            fwd0ffts8<log_N-3>()(fft, y+N2, x+N2, W);
            fwd0ffts8<log_N-3>()(fft, y+N3, x+N3, W);
            fwd0ffts8<log_N-3>()(fft, y+N4, x+N4, W);
            fwd0ffts8<log_N-3>()(fft, y+N5, x+N5, W);
            fwd0ffts8<log_N-3>()(fft, y+N6, x+N6, W);
            fwd0ffts8<log_N-3>()(fft, y+N7, x+N7, W);
            for (int p = 0; p < N1; p += 2) {
                /*
                //setpz(x[2*p+0], getpz(y[p+0]));
                //setpz(x[2*p+1], getpz(y[p+m]));
                const ymm ab = getpz2(y+p+0);
                const ymm cd = getpz2(y+p+m);
                const ymm ac = catlo(ab, cd);
                const ymm bd = cathi(ab, cd);
                setpz2(x+2*p+0, ac);
                setpz2(x+2*p+2, bd);
                */
                transpose_kernel(p, y, x);
            }
        }
        else {
            #pragma omp parallel for schedule(guided)
            for (int p = 0; p < N1; p += 2) {
                /*
                const ymm wp = getpz2(W+p);
                const ymm a  = getpz2(x+p+0);
                const ymm b  = getpz2(x+p+m);
                setpz2(y+p+0,            addpz2(a, b));
                setpz2(y+p+m, mulpz2(wp, subpz2(a, b)));
                */
                mult_twiddle_factor_kernel(p, x, y, W);
            }
            //fwd0ffts2<log_N-1>()(fft, y+0, x+0, W);
            //fwd0ffts2<log_N-1>()(fft, y+m, x+m, W);
            fwd0ffts8<log_N-3>()(fft, y+N0, x+N0, W);
            fwd0ffts8<log_N-3>()(fft, y+N1, x+N1, W);
            fwd0ffts8<log_N-3>()(fft, y+N2, x+N2, W);
            fwd0ffts8<log_N-3>()(fft, y+N3, x+N3, W);
            fwd0ffts8<log_N-3>()(fft, y+N4, x+N4, W);
            fwd0ffts8<log_N-3>()(fft, y+N5, x+N5, W);
            fwd0ffts8<log_N-3>()(fft, y+N6, x+N6, W);
            fwd0ffts8<log_N-3>()(fft, y+N7, x+N7, W);
            #pragma omp parallel for schedule(static)
            for (int p = 0; p < N1; p += 2) {
                /*
                //setpz(x[2*p+0], getpz(y[p+0]));
                //setpz(x[2*p+1], getpz(y[p+m]));
                const ymm ab = getpz2(y+p+0);
                const ymm cd = getpz2(y+p+m);
                const ymm ac = catlo(ab, cd);
                const ymm bd = cathi(ab, cd);
                setpz2(x+2*p+0, ac);
                setpz2(x+2*p+2, bd);
                */
                transpose_kernel(p, y, x);
            }
        }
    }
};

///////////////////////////////////////////////////////////////////////////////

template <int log_N> struct inv0fftq
{
    static const int N = 1 << log_N;
    static const int N0 = 0;
    static const int N1 = N/8;
    static const int N2 = N/4;
    static const int N3 = N1 + N2;
    static const int N4 = N/2;
    static const int N5 = N2 + N3;
    static const int N6 = N3 + N3;
    static const int N7 = N3 + N4;

    static inline void transpose_kernel(
            const int p, complex_vector x, complex_vector y)
    {
        fwd0fftq<log_N>::transpose_kernel(p, x, y);
    }

    static inline void mult_twiddle_factor_kernel(const int p,
            complex_vector x, complex_vector y, const_complex_vector W)
    {
        const ymm w1p = cnjpz2(getpz2(W+p));
        const ymm w2p = mulpz2(w1p, w1p);
        const ymm w3p = mulpz2(w1p, w2p);
        const ymm w4p = mulpz2(w2p, w2p);
        const ymm w5p = mulpz2(w2p, w3p);
        const ymm w6p = mulpz2(w3p, w3p);
        const ymm w7p = mulpz2(w3p, w4p);
        const ymm a = getpz2(x+p+N0);
        const ymm b = getpz2(x+p+N1);
        const ymm c = getpz2(x+p+N2);
        const ymm d = getpz2(x+p+N3);
        const ymm e = getpz2(x+p+N4);
        const ymm f = getpz2(x+p+N5);
        const ymm g = getpz2(x+p+N6);
        const ymm h = getpz2(x+p+N7);
        const ymm jc = jxpz2(c);
        const ymm jd = jxpz2(d);
        const ymm jg = jxpz2(g);
        const ymm jh = jxpz2(h);
        const ymm ap1c = addpz2(a,  c);
        const ymm amjc = subpz2(a, jc);
        const ymm am1c = subpz2(a,  c);
        const ymm apjc = addpz2(a, jc);
        const ymm bp1d = addpz2(b,  d);
        const ymm bmjd = subpz2(b, jd);
        const ymm bm1d = subpz2(b,  d);
        const ymm bpjd = addpz2(b, jd);
        const ymm ep1g = addpz2(e,  g);
        const ymm emjg = subpz2(e, jg);
        const ymm em1g = subpz2(e,  g);
        const ymm epjg = addpz2(e, jg);
        const ymm fp1h = addpz2(f,  h);
        const ymm fmjh = subpz2(f, jh);
        const ymm fm1h = subpz2(f,  h);
        const ymm fpjh = addpz2(f, jh);
        const ymm   ap1c_p_ep1g =        addpz2(ap1c, ep1g);
        const ymm   bp1d_p_fp1h =        addpz2(bp1d, fp1h);
        const ymm   amjc_m_emjg =        subpz2(amjc, emjg);
        const ymm w8bmjd_m_fmjh = w8xpz2(subpz2(bmjd, fmjh));
        const ymm   am1c_p_em1g =        addpz2(am1c, em1g);
        const ymm jxbm1d_p_fm1h =  jxpz2(addpz2(bm1d, fm1h));
        const ymm   apjc_m_epjg =        subpz2(apjc, epjg);
        const ymm v8bpjd_m_fpjh = v8xpz2(subpz2(bpjd, fpjh));
        setpz2(y+p+N0,             addpz2(ap1c_p_ep1g,   bp1d_p_fp1h));
        setpz2(y+p+N1, mulpz2(w1p, addpz2(apjc_m_epjg, v8bpjd_m_fpjh)));
        setpz2(y+p+N2, mulpz2(w2p, addpz2(am1c_p_em1g, jxbm1d_p_fm1h)));
        setpz2(y+p+N3, mulpz2(w3p, subpz2(amjc_m_emjg, w8bmjd_m_fmjh)));
        setpz2(y+p+N4, mulpz2(w4p, subpz2(ap1c_p_ep1g,   bp1d_p_fp1h)));
        setpz2(y+p+N5, mulpz2(w5p, subpz2(apjc_m_epjg, v8bpjd_m_fpjh)));
        setpz2(y+p+N6, mulpz2(w6p, subpz2(am1c_p_em1g, jxbm1d_p_fm1h)));
        setpz2(y+p+N7, mulpz2(w7p, addpz2(amjc_m_emjg, w8bmjd_m_fmjh)));
    }

    template <typename fft_t>
    void operator()(const fft_t& fft,
            complex_vector x, complex_vector y, const_complex_vector W) const
    {
        if (N < OMP_THRESHOLD1) {
            for (int p = 0; p < N1; p += 2) {
                /*
                const ymm wp = cnjpz2(getpz2(W+p));
                const ymm a  = getpz2(x+p+0);
                const ymm b  = getpz2(x+p+m);
                setpz2(y+p+0,            addpz2(a, b));
                setpz2(y+p+m, mulpz2(wp, subpz2(a, b)));
                */
                mult_twiddle_factor_kernel(p, x, y, W);
            }
            //inv0ffts2<log_N-1>()(fft, y+0, x+0, W);
            //inv0ffts2<log_N-1>()(fft, y+m, x+m, W);
            inv0ffts8<log_N-3>()(fft, y+N0, x+N0, W);
            inv0ffts8<log_N-3>()(fft, y+N1, x+N1, W);
            inv0ffts8<log_N-3>()(fft, y+N2, x+N2, W);
            inv0ffts8<log_N-3>()(fft, y+N3, x+N3, W);
            inv0ffts8<log_N-3>()(fft, y+N4, x+N4, W);
            inv0ffts8<log_N-3>()(fft, y+N5, x+N5, W);
            inv0ffts8<log_N-3>()(fft, y+N6, x+N6, W);
            inv0ffts8<log_N-3>()(fft, y+N7, x+N7, W);
            for (int p = 0; p < N1; p += 2) {
                /*
                //setpz(x[2*p+0], getpz(y[p+0]));
                //setpz(x[2*p+1], getpz(y[p+m]));
                const ymm ab = getpz2(y+p+0);
                const ymm cd = getpz2(y+p+m);
                const ymm ac = catlo(ab, cd);
                const ymm bd = cathi(ab, cd);
                setpz2(x+2*p+0, ac);
                setpz2(x+2*p+2, bd);
                */
                transpose_kernel(p, y, x);
            }
        }
        else {
            #pragma omp parallel for schedule(guided)
            for (int p = 0; p < N1; p += 2) {
                /*
                const ymm wp = cnjpz2(getpz2(W+p));
                const ymm a  = getpz2(x+p+0);
                const ymm b  = getpz2(x+p+m);
                setpz2(y+p+0,            addpz2(a, b));
                setpz2(y+p+m, mulpz2(wp, subpz2(a, b)));
                */
                mult_twiddle_factor_kernel(p, x, y, W);
            }
            //inv0ffts2<log_N-1>()(fft, y+0, x+0, W);
            //inv0ffts2<log_N-1>()(fft, y+m, x+m, W);
            inv0ffts8<log_N-3>()(fft, y+N0, x+N0, W);
            inv0ffts8<log_N-3>()(fft, y+N1, x+N1, W);
            inv0ffts8<log_N-3>()(fft, y+N2, x+N2, W);
            inv0ffts8<log_N-3>()(fft, y+N3, x+N3, W);
            inv0ffts8<log_N-3>()(fft, y+N4, x+N4, W);
            inv0ffts8<log_N-3>()(fft, y+N5, x+N5, W);
            inv0ffts8<log_N-3>()(fft, y+N6, x+N6, W);
            inv0ffts8<log_N-3>()(fft, y+N7, x+N7, W);
            #pragma omp parallel for schedule(static)
            for (int p = 0; p < N1; p += 2) {
                /*
                //setpz(x[2*p+0], getpz(y[p+0]));
                //setpz(x[2*p+1], getpz(y[p+m]));
                const ymm ab = getpz2(y+p+0);
                const ymm cd = getpz2(y+p+m);
                const ymm ac = catlo(ab, cd);
                const ymm bd = cathi(ab, cd);
                setpz2(x+2*p+0, ac);
                setpz2(x+2*p+2, bd);
                */
                transpose_kernel(p, y, x);
            }
        }
    }
};

///////////////////////////////////////////////////////////////////////////////

template <int log_N> struct fwdnfftq
{
    static const int N = 1 << log_N;
    static const int N0 = 0;
    static const int N1 = N/8;
    static const int N2 = N/4;
    static const int N3 = N1 + N2;
    static const int N4 = N/2;
    static const int N5 = N2 + N3;
    static const int N6 = N3 + N3;
    static const int N7 = N3 + N4;

    static inline void transpose_kernel(
            const int p, complex_vector x, complex_vector y)
    {
        fwd0fftq<log_N>::transpose_kernel(p, x, y);
    }

    static inline void mult_twiddle_factor_kernel(const int p,
            complex_vector x, complex_vector y, const_complex_vector W)
    {
        static const ymm rN = { 1.0/N, 1.0/N, 1.0/N, 1.0/N };
        const ymm w1p = getpz2(W+p);
        const ymm w2p = mulpz2(w1p, w1p);
        const ymm w3p = mulpz2(w1p, w2p);
        const ymm w4p = mulpz2(w2p, w2p);
        const ymm w5p = mulpz2(w2p, w3p);
        const ymm w6p = mulpz2(w3p, w3p);
        const ymm w7p = mulpz2(w3p, w4p);
        const ymm a = mulpd2(rN, getpz2(x+p+N0));
        const ymm b = mulpd2(rN, getpz2(x+p+N1));
        const ymm c = mulpd2(rN, getpz2(x+p+N2));
        const ymm d = mulpd2(rN, getpz2(x+p+N3));
        const ymm e = mulpd2(rN, getpz2(x+p+N4));
        const ymm f = mulpd2(rN, getpz2(x+p+N5));
        const ymm g = mulpd2(rN, getpz2(x+p+N6));
        const ymm h = mulpd2(rN, getpz2(x+p+N7));
        const ymm jc = jxpz2(c);
        const ymm jd = jxpz2(d);
        const ymm jg = jxpz2(g);
        const ymm jh = jxpz2(h);
        const ymm ap1c = addpz2(a,  c);
        const ymm amjc = subpz2(a, jc);
        const ymm am1c = subpz2(a,  c);
        const ymm apjc = addpz2(a, jc);
        const ymm bp1d = addpz2(b,  d);
        const ymm bmjd = subpz2(b, jd);
        const ymm bm1d = subpz2(b,  d);
        const ymm bpjd = addpz2(b, jd);
        const ymm ep1g = addpz2(e,  g);
        const ymm emjg = subpz2(e, jg);
        const ymm em1g = subpz2(e,  g);
        const ymm epjg = addpz2(e, jg);
        const ymm fp1h = addpz2(f,  h);
        const ymm fmjh = subpz2(f, jh);
        const ymm fm1h = subpz2(f,  h);
        const ymm fpjh = addpz2(f, jh);
        const ymm   ap1c_p_ep1g =        addpz2(ap1c, ep1g);
        const ymm   bp1d_p_fp1h =        addpz2(bp1d, fp1h);
        const ymm   amjc_m_emjg =        subpz2(amjc, emjg);
        const ymm w8bmjd_m_fmjh = w8xpz2(subpz2(bmjd, fmjh));
        const ymm   am1c_p_em1g =        addpz2(am1c, em1g);
        const ymm jxbm1d_p_fm1h =  jxpz2(addpz2(bm1d, fm1h));
        const ymm   apjc_m_epjg =        subpz2(apjc, epjg);
        const ymm v8bpjd_m_fpjh = v8xpz2(subpz2(bpjd, fpjh));
        setpz2(y+p+N0,             addpz2(ap1c_p_ep1g,   bp1d_p_fp1h));
        setpz2(y+p+N1, mulpz2(w1p, addpz2(amjc_m_emjg, w8bmjd_m_fmjh)));
        setpz2(y+p+N2, mulpz2(w2p, subpz2(am1c_p_em1g, jxbm1d_p_fm1h)));
        setpz2(y+p+N3, mulpz2(w3p, subpz2(apjc_m_epjg, v8bpjd_m_fpjh)));
        setpz2(y+p+N4, mulpz2(w4p, subpz2(ap1c_p_ep1g,   bp1d_p_fp1h)));
        setpz2(y+p+N5, mulpz2(w5p, subpz2(amjc_m_emjg, w8bmjd_m_fmjh)));
        setpz2(y+p+N6, mulpz2(w6p, addpz2(am1c_p_em1g, jxbm1d_p_fm1h)));
        setpz2(y+p+N7, mulpz2(w7p, addpz2(apjc_m_epjg, v8bpjd_m_fpjh)));
    }

    template <typename fft_t>
    void operator()(const fft_t& fft,
            complex_vector x, complex_vector y, const_complex_vector W) const
    {
        if (N < OMP_THRESHOLD1) {
            for (int p = 0; p < N1; p += 2) {
                /*
                const ymm wp = getpz2(W+p);
                const ymm  a = mulpd2(rN, getpz2(x+p+0));
                const ymm  b = mulpd2(rN, getpz2(x+p+m));
                setpz2(y+p+0,            addpz2(a, b));
                setpz2(y+p+m, mulpz2(wp, subpz2(a, b)));
                */
                mult_twiddle_factor_kernel(p, x, y, W);
            }
            //fwd0ffts2<log_N-1>()(fft, y+0, x+0, W);
            //fwd0ffts2<log_N-1>()(fft, y+m, x+m, W);
            fwd0ffts8<log_N-3>()(fft, y+N0, x+N0, W);
            fwd0ffts8<log_N-3>()(fft, y+N1, x+N1, W);
            fwd0ffts8<log_N-3>()(fft, y+N2, x+N2, W);
            fwd0ffts8<log_N-3>()(fft, y+N3, x+N3, W);
            fwd0ffts8<log_N-3>()(fft, y+N4, x+N4, W);
            fwd0ffts8<log_N-3>()(fft, y+N5, x+N5, W);
            fwd0ffts8<log_N-3>()(fft, y+N6, x+N6, W);
            fwd0ffts8<log_N-3>()(fft, y+N7, x+N7, W);
            for (int p = 0; p < N1; p += 2) {
                /*
                //setpz(x[2*p+0], getpz(y[p+0]));
                //setpz(x[2*p+1], getpz(y[p+m]));
                const ymm ab = getpz2(y+p+0);
                const ymm cd = getpz2(y+p+m);
                const ymm ac = catlo(ab, cd);
                const ymm bd = cathi(ab, cd);
                setpz2(x+2*p+0, ac);
                setpz2(x+2*p+2, bd);
                */
                transpose_kernel(p, y, x);
            }
        }
        else {
            #pragma omp parallel for schedule(guided)
            for (int p = 0; p < N1; p += 2) {
                /*
                const ymm wp = getpz2(W+p);
                const ymm  a = mulpd2(rN, getpz2(x+p+0));
                const ymm  b = mulpd2(rN, getpz2(x+p+m));
                setpz2(y+p+0,            addpz2(a, b));
                setpz2(y+p+m, mulpz2(wp, subpz2(a, b)));
                */
                mult_twiddle_factor_kernel(p, x, y, W);
            }
            //fwd0ffts2<log_N-1>()(fft, y+0, x+0, W);
            //fwd0ffts2<log_N-1>()(fft, y+m, x+m, W);
            fwd0ffts8<log_N-3>()(fft, y+N0, x+N0, W);
            fwd0ffts8<log_N-3>()(fft, y+N1, x+N1, W);
            fwd0ffts8<log_N-3>()(fft, y+N2, x+N2, W);
            fwd0ffts8<log_N-3>()(fft, y+N3, x+N3, W);
            fwd0ffts8<log_N-3>()(fft, y+N4, x+N4, W);
            fwd0ffts8<log_N-3>()(fft, y+N5, x+N5, W);
            fwd0ffts8<log_N-3>()(fft, y+N6, x+N6, W);
            fwd0ffts8<log_N-3>()(fft, y+N7, x+N7, W);
            #pragma omp parallel for schedule(static)
            for (int p = 0; p < N1; p += 2) {
                /*
                //setpz(x[2*p+0], getpz(y[p+0]));
                //setpz(x[2*p+1], getpz(y[p+m]));
                const ymm ab = getpz2(y+p+0);
                const ymm cd = getpz2(y+p+m);
                const ymm ac = catlo(ab, cd);
                const ymm bd = cathi(ab, cd);
                setpz2(x+2*p+0, ac);
                setpz2(x+2*p+2, bd);
                */
                transpose_kernel(p, y, x);
            }
        }
    }
};

///////////////////////////////////////////////////////////////////////////////

template <int log_N> struct invnfftq
{
    static const int N = 1 << log_N;
    static const int N0 = 0;
    static const int N1 = N/8;
    static const int N2 = N/4;
    static const int N3 = N1 + N2;
    static const int N4 = N/2;
    static const int N5 = N2 + N3;
    static const int N6 = N3 + N3;
    static const int N7 = N3 + N4;

    static inline void transpose_kernel(
            const int p, complex_vector x, complex_vector y)
    {
        fwd0fftq<log_N>::transpose_kernel(p, x, y);
    }

    static inline void mult_twiddle_factor_kernel(const int p,
            complex_vector x, complex_vector y, const_complex_vector W)
    {
        static const ymm rN = { 1.0/N, 1.0/N, 1.0/N, 1.0/N };
        const ymm w1p = cnjpz2(getpz2(W+p));
        const ymm w2p = mulpz2(w1p, w1p);
        const ymm w3p = mulpz2(w1p, w2p);
        const ymm w4p = mulpz2(w2p, w2p);
        const ymm w5p = mulpz2(w2p, w3p);
        const ymm w6p = mulpz2(w3p, w3p);
        const ymm w7p = mulpz2(w3p, w4p);
        const ymm a = mulpd2(rN, getpz2(x+p+N0));
        const ymm b = mulpd2(rN, getpz2(x+p+N1));
        const ymm c = mulpd2(rN, getpz2(x+p+N2));
        const ymm d = mulpd2(rN, getpz2(x+p+N3));
        const ymm e = mulpd2(rN, getpz2(x+p+N4));
        const ymm f = mulpd2(rN, getpz2(x+p+N5));
        const ymm g = mulpd2(rN, getpz2(x+p+N6));
        const ymm h = mulpd2(rN, getpz2(x+p+N7));
        const ymm jc = jxpz2(c);
        const ymm jd = jxpz2(d);
        const ymm jg = jxpz2(g);
        const ymm jh = jxpz2(h);
        const ymm ap1c = addpz2(a,  c);
        const ymm amjc = subpz2(a, jc);
        const ymm am1c = subpz2(a,  c);
        const ymm apjc = addpz2(a, jc);
        const ymm bp1d = addpz2(b,  d);
        const ymm bmjd = subpz2(b, jd);
        const ymm bm1d = subpz2(b,  d);
        const ymm bpjd = addpz2(b, jd);
        const ymm ep1g = addpz2(e,  g);
        const ymm emjg = subpz2(e, jg);
        const ymm em1g = subpz2(e,  g);
        const ymm epjg = addpz2(e, jg);
        const ymm fp1h = addpz2(f,  h);
        const ymm fmjh = subpz2(f, jh);
        const ymm fm1h = subpz2(f,  h);
        const ymm fpjh = addpz2(f, jh);
        const ymm   ap1c_p_ep1g =        addpz2(ap1c, ep1g);
        const ymm   bp1d_p_fp1h =        addpz2(bp1d, fp1h);
        const ymm   amjc_m_emjg =        subpz2(amjc, emjg);
        const ymm w8bmjd_m_fmjh = w8xpz2(subpz2(bmjd, fmjh));
        const ymm   am1c_p_em1g =        addpz2(am1c, em1g);
        const ymm jxbm1d_p_fm1h =  jxpz2(addpz2(bm1d, fm1h));
        const ymm   apjc_m_epjg =        subpz2(apjc, epjg);
        const ymm v8bpjd_m_fpjh = v8xpz2(subpz2(bpjd, fpjh));
        setpz2(y+p+N0,             addpz2(ap1c_p_ep1g,   bp1d_p_fp1h));
        setpz2(y+p+N1, mulpz2(w1p, addpz2(apjc_m_epjg, v8bpjd_m_fpjh)));
        setpz2(y+p+N2, mulpz2(w2p, addpz2(am1c_p_em1g, jxbm1d_p_fm1h)));
        setpz2(y+p+N3, mulpz2(w3p, subpz2(amjc_m_emjg, w8bmjd_m_fmjh)));
        setpz2(y+p+N4, mulpz2(w4p, subpz2(ap1c_p_ep1g,   bp1d_p_fp1h)));
        setpz2(y+p+N5, mulpz2(w5p, subpz2(apjc_m_epjg, v8bpjd_m_fpjh)));
        setpz2(y+p+N6, mulpz2(w6p, subpz2(am1c_p_em1g, jxbm1d_p_fm1h)));
        setpz2(y+p+N7, mulpz2(w7p, addpz2(amjc_m_emjg, w8bmjd_m_fmjh)));
    }

    template <typename fft_t>
    void operator()(const fft_t& fft,
            complex_vector x, complex_vector y, const_complex_vector W) const
    {
        if (N < OMP_THRESHOLD1) {
            for (int p = 0; p < N1; p += 2) {
                /*
                const ymm wp = cnjpz2(getpz2(W+p));
                const ymm a  = mulpd2(rN, getpz2(x+p+0));
                const ymm b  = mulpd2(rN, getpz2(x+p+m));
                setpz2(y+p+0,            addpz2(a, b));
                setpz2(y+p+m, mulpz2(wp, subpz2(a, b)));
                */
                mult_twiddle_factor_kernel(p, x, y, W);
            }
            //inv0ffts2<log_N-1>()(fft, y+0, x+0, W);
            //inv0ffts2<log_N-1>()(fft, y+m, x+m, W);
            inv0ffts8<log_N-3>()(fft, y+N0, x+N0, W);
            inv0ffts8<log_N-3>()(fft, y+N1, x+N1, W);
            inv0ffts8<log_N-3>()(fft, y+N2, x+N2, W);
            inv0ffts8<log_N-3>()(fft, y+N3, x+N3, W);
            inv0ffts8<log_N-3>()(fft, y+N4, x+N4, W);
            inv0ffts8<log_N-3>()(fft, y+N5, x+N5, W);
            inv0ffts8<log_N-3>()(fft, y+N6, x+N6, W);
            inv0ffts8<log_N-3>()(fft, y+N7, x+N7, W);
            for (int p = 0; p < N1; p += 2) {
                /*
                //setpz(x[2*p+0], getpz(y[p+0]));
                //setpz(x[2*p+1], getpz(y[p+m]));
                const ymm ab = getpz2(y+p+0);
                const ymm cd = getpz2(y+p+m);
                const ymm ac = catlo(ab, cd);
                const ymm bd = cathi(ab, cd);
                setpz2(x+2*p+0, ac);
                setpz2(x+2*p+2, bd);
                */
                transpose_kernel(p, y, x);
            }
        }
        else {
            #pragma omp parallel for schedule(guided)
            for (int p = 0; p < N1; p += 2) {
                /*
                const ymm wp = cnjpz2(getpz2(W+p));
                const ymm a  = mulpd2(rN, getpz2(x+p+0));
                const ymm b  = mulpd2(rN, getpz2(x+p+m));
                setpz2(y+p+0,            addpz2(a, b));
                setpz2(y+p+m, mulpz2(wp, subpz2(a, b)));
                */
                mult_twiddle_factor_kernel(p, x, y, W);
            }
            //inv0ffts2<log_N-1>()(fft, y+0, x+0, W);
            //inv0ffts2<log_N-1>()(fft, y+m, x+m, W);
            inv0ffts8<log_N-3>()(fft, y+N0, x+N0, W);
            inv0ffts8<log_N-3>()(fft, y+N1, x+N1, W);
            inv0ffts8<log_N-3>()(fft, y+N2, x+N2, W);
            inv0ffts8<log_N-3>()(fft, y+N3, x+N3, W);
            inv0ffts8<log_N-3>()(fft, y+N4, x+N4, W);
            inv0ffts8<log_N-3>()(fft, y+N5, x+N5, W);
            inv0ffts8<log_N-3>()(fft, y+N6, x+N6, W);
            inv0ffts8<log_N-3>()(fft, y+N7, x+N7, W);
            #pragma omp parallel for schedule(static)
            for (int p = 0; p < N1; p += 2) {
                /*
                //setpz(x[2*p+0], getpz(y[p+0]));
                //setpz(x[2*p+1], getpz(y[p+m]));
                const ymm ab = getpz2(y+p+0);
                const ymm cd = getpz2(y+p+m);
                const ymm ac = catlo(ab, cd);
                const ymm bd = cathi(ab, cd);
                setpz2(x+2*p+0, ac);
                setpz2(x+2*p+2, bd);
                */
                transpose_kernel(p, y, x);
            }
        }
    }
};

///////////////////////////////////////////////////////////////////////////////

struct FFT0
{
    int N, log_N;
    simd_array<complex_t> weight;
    complex_t* __restrict W;
    OTFFT_AVXDIFx::FFT0 fft;

    FFT0() : N(0), log_N(0), W(0) {}
    FFT0(const int n) { setup(n); }

    void setup(int n)
    {
        for (log_N = 0; n > 1; n >>= 1) log_N++;
        setup2(log_N);
    }

    inline void setup2(const int n)
    {
        log_N = n; N = 1 << n;
        weight.setup(N+1); W = &weight;
        if (N < 16)
            fft.setup2(n);
        else if ((n & 1) == 1)
            fft.setup2(n/2-1);
        else
            fft.setup2(n/2);
        init_W(N, W);
    }

    inline void fwd(complex_vector x, complex_vector y) const
    {
        switch (log_N) {
            case  0: break;
            case  1: fft.fwd(x, y); break;
            case  2: fft.fwd(x, y); break;
            case  3: fft.fwd(x, y); break;
            case  4: fwdnffts< 4>()(fft, x, y, W); break;
            case  5: fwdnfftq< 5>()(fft, x, y, W); break;
            case  6: fwdnffts< 6>()(fft, x, y, W); break;
            case  7: fwdnfftq< 7>()(fft, x, y, W); break;
            case  8: fwdnffts< 8>()(fft, x, y, W); break;
            case  9: fwdnfftq< 9>()(fft, x, y, W); break;
            case 10: fwdnffts<10>()(fft, x, y, W); break;
            case 11: fwdnfftq<11>()(fft, x, y, W); break;
            case 12: fwdnffts<12>()(fft, x, y, W); break;
            case 13: fwdnfftq<13>()(fft, x, y, W); break;
            case 14: fwdnffts<14>()(fft, x, y, W); break;
            case 15: fwdnfftq<15>()(fft, x, y, W); break;
            case 16: fwdnffts<16>()(fft, x, y, W); break;
            case 17: fwdnfftq<17>()(fft, x, y, W); break;
            case 18: fwdnffts<18>()(fft, x, y, W); break;
            case 19: fwdnfftq<19>()(fft, x, y, W); break;
            case 20: fwdnffts<20>()(fft, x, y, W); break;
            case 21: fwdnfftq<21>()(fft, x, y, W); break;
            case 22: fwdnffts<22>()(fft, x, y, W); break;
            case 23: fwdnfftq<23>()(fft, x, y, W); break;
            case 24: fwdnffts<24>()(fft, x, y, W); break;
        }
    }

    inline void fwd0(complex_vector x, complex_vector y) const
    {
        switch (log_N) {
            case  0: break;
            case  1: fft.fwd0(x, y); break;
            case  2: fft.fwd0(x, y); break;
            case  3: fft.fwd0(x, y); break;
            case  4: fwd0ffts< 4>()(fft, x, y, W); break;
            case  5: fwd0fftq< 5>()(fft, x, y, W); break;
            case  6: fwd0ffts< 6>()(fft, x, y, W); break;
            case  7: fwd0fftq< 7>()(fft, x, y, W); break;
            case  8: fwd0ffts< 8>()(fft, x, y, W); break;
            case  9: fwd0fftq< 9>()(fft, x, y, W); break;
            case 10: fwd0ffts<10>()(fft, x, y, W); break;
            case 11: fwd0fftq<11>()(fft, x, y, W); break;
            case 12: fwd0ffts<12>()(fft, x, y, W); break;
            case 13: fwd0fftq<13>()(fft, x, y, W); break;
            case 14: fwd0ffts<14>()(fft, x, y, W); break;
            case 15: fwd0fftq<15>()(fft, x, y, W); break;
            case 16: fwd0ffts<16>()(fft, x, y, W); break;
            case 17: fwd0fftq<17>()(fft, x, y, W); break;
            case 18: fwd0ffts<18>()(fft, x, y, W); break;
            case 19: fwd0fftq<19>()(fft, x, y, W); break;
            case 20: fwd0ffts<20>()(fft, x, y, W); break;
            case 21: fwd0fftq<21>()(fft, x, y, W); break;
            case 22: fwd0ffts<22>()(fft, x, y, W); break;
            case 23: fwd0fftq<23>()(fft, x, y, W); break;
            case 24: fwd0ffts<24>()(fft, x, y, W); break;
        }
    }

    inline void fwdn(complex_vector x, complex_vector y) const { fwd(x, y); }

    inline void inv(complex_vector x, complex_vector y) const
    {
        switch (log_N) {
            case  0: break;
            case  1: fft.inv0(x, y); break;
            case  2: fft.inv0(x, y); break;
            case  3: fft.inv0(x, y); break;
            case  4: inv0ffts< 4>()(fft, x, y, W); break;
            case  5: inv0fftq< 5>()(fft, x, y, W); break;
            case  6: inv0ffts< 6>()(fft, x, y, W); break;
            case  7: inv0fftq< 7>()(fft, x, y, W); break;
            case  8: inv0ffts< 8>()(fft, x, y, W); break;
            case  9: inv0fftq< 9>()(fft, x, y, W); break;
            case 10: inv0ffts<10>()(fft, x, y, W); break;
            case 11: inv0fftq<11>()(fft, x, y, W); break;
            case 12: inv0ffts<12>()(fft, x, y, W); break;
            case 13: inv0fftq<13>()(fft, x, y, W); break;
            case 14: inv0ffts<14>()(fft, x, y, W); break;
            case 15: inv0fftq<15>()(fft, x, y, W); break;
            case 16: inv0ffts<16>()(fft, x, y, W); break;
            case 17: inv0fftq<17>()(fft, x, y, W); break;
            case 18: inv0ffts<18>()(fft, x, y, W); break;
            case 19: inv0fftq<19>()(fft, x, y, W); break;
            case 20: inv0ffts<20>()(fft, x, y, W); break;
            case 21: inv0fftq<21>()(fft, x, y, W); break;
            case 22: inv0ffts<22>()(fft, x, y, W); break;
            case 23: inv0fftq<23>()(fft, x, y, W); break;
            case 24: inv0ffts<24>()(fft, x, y, W); break;
        }
    }

    inline void inv0(complex_vector x, complex_vector y) const { inv(x, y); }

    inline void invn(complex_vector x, complex_vector y) const
    {
        switch (log_N) {
            case  0: break;
            case  1: fft.invn(x, y); break;
            case  2: fft.invn(x, y); break;
            case  3: fft.invn(x, y); break;
            case  4: invnffts< 4>()(fft, x, y, W); break;
            case  5: invnfftq< 5>()(fft, x, y, W); break;
            case  6: invnffts< 6>()(fft, x, y, W); break;
            case  7: invnfftq< 7>()(fft, x, y, W); break;
            case  8: invnffts< 8>()(fft, x, y, W); break;
            case  9: invnfftq< 9>()(fft, x, y, W); break;
            case 10: invnffts<10>()(fft, x, y, W); break;
            case 11: invnfftq<11>()(fft, x, y, W); break;
            case 12: invnffts<12>()(fft, x, y, W); break;
            case 13: invnfftq<13>()(fft, x, y, W); break;
            case 14: invnffts<14>()(fft, x, y, W); break;
            case 15: invnfftq<15>()(fft, x, y, W); break;
            case 16: invnffts<16>()(fft, x, y, W); break;
            case 17: invnfftq<17>()(fft, x, y, W); break;
            case 18: invnffts<18>()(fft, x, y, W); break;
            case 19: invnfftq<19>()(fft, x, y, W); break;
            case 20: invnffts<20>()(fft, x, y, W); break;
            case 21: invnfftq<21>()(fft, x, y, W); break;
            case 22: invnffts<22>()(fft, x, y, W); break;
            case 23: invnfftq<23>()(fft, x, y, W); break;
            case 24: invnffts<24>()(fft, x, y, W); break;
        }
    }
};

#if 0
struct FFT1
{
    int N, log_N;
    simd_array<complex_t> weight;
    complex_t* __restrict W;
    OTFFT_AVXDIFx::FFT0 fft1, fft2;

    FFT1() : N(0), log_N(0), W(0) {}
    FFT1(const int n) { setup(n); }

    void setup(int n)
    {
        for (log_N = 0; n > 1; n >>= 1) log_N++;
        setup2(log_N);
    }

    inline void setup2(const int n)
    {
        log_N = n; N = 1 << n;
        weight.setup(N+1); W = &weight;
        if (N < 4) fft1.setup2(n);
        else { fft1.setup2(n/2); fft2.setup2(n - n/2); }
        init_W(N, W);
    }

    inline void fwd(complex_vector x, complex_vector y) const
    {
        switch (log_N) {
            case  0: break;
            case  1: fft1.fwd(x, y); break;
            case  2: fwdnfftr< 2>()(fft1, fft2, x, y, W); break;
            case  3: fwdnfftr< 3>()(fft1, fft2, x, y, W); break;
            case  4: fwdnfftr< 4>()(fft1, fft2, x, y, W); break;
            case  5: fwdnfftr< 5>()(fft1, fft2, x, y, W); break;
            case  6: fwdnfftr< 6>()(fft1, fft2, x, y, W); break;
            case  7: fwdnfftr< 7>()(fft1, fft2, x, y, W); break;
            case  8: fwdnfftr< 8>()(fft1, fft2, x, y, W); break;
            case  9: fwdnfftr< 9>()(fft1, fft2, x, y, W); break;
            case 10: fwdnfftr<10>()(fft1, fft2, x, y, W); break;
            case 11: fwdnfftr<11>()(fft1, fft2, x, y, W); break;
            case 12: fwdnfftr<12>()(fft1, fft2, x, y, W); break;
            case 13: fwdnfftr<13>()(fft1, fft2, x, y, W); break;
            case 14: fwdnfftr<14>()(fft1, fft2, x, y, W); break;
            case 15: fwdnfftr<15>()(fft1, fft2, x, y, W); break;
            case 16: fwdnfftr<16>()(fft1, fft2, x, y, W); break;
            case 17: fwdnfftr<17>()(fft1, fft2, x, y, W); break;
            case 18: fwdnfftr<18>()(fft1, fft2, x, y, W); break;
            case 19: fwdnfftr<19>()(fft1, fft2, x, y, W); break;
            case 20: fwdnfftr<20>()(fft1, fft2, x, y, W); break;
            case 21: fwdnfftr<21>()(fft1, fft2, x, y, W); break;
            case 22: fwdnfftr<22>()(fft1, fft2, x, y, W); break;
            case 23: fwdnfftr<23>()(fft1, fft2, x, y, W); break;
            case 24: fwdnfftr<24>()(fft1, fft2, x, y, W); break;
        }
    }

    inline void fwd0(complex_vector x, complex_vector y) const
    {
        switch (log_N) {
            case  0: break;
            case  1: fft1.fwd0(x, y); break;
            case  2: fwd0fftr< 2>()(fft1, fft2, x, y, W); break;
            case  3: fwd0fftr< 3>()(fft1, fft2, x, y, W); break;
            case  4: fwd0fftr< 4>()(fft1, fft2, x, y, W); break;
            case  5: fwd0fftr< 5>()(fft1, fft2, x, y, W); break;
            case  6: fwd0fftr< 6>()(fft1, fft2, x, y, W); break;
            case  7: fwd0fftr< 7>()(fft1, fft2, x, y, W); break;
            case  8: fwd0fftr< 8>()(fft1, fft2, x, y, W); break;
            case  9: fwd0fftr< 9>()(fft1, fft2, x, y, W); break;
            case 10: fwd0fftr<10>()(fft1, fft2, x, y, W); break;
            case 11: fwd0fftr<11>()(fft1, fft2, x, y, W); break;
            case 12: fwd0fftr<12>()(fft1, fft2, x, y, W); break;
            case 13: fwd0fftr<13>()(fft1, fft2, x, y, W); break;
            case 14: fwd0fftr<14>()(fft1, fft2, x, y, W); break;
            case 15: fwd0fftr<15>()(fft1, fft2, x, y, W); break;
            case 16: fwd0fftr<16>()(fft1, fft2, x, y, W); break;
            case 17: fwd0fftr<17>()(fft1, fft2, x, y, W); break;
            case 18: fwd0fftr<18>()(fft1, fft2, x, y, W); break;
            case 19: fwd0fftr<19>()(fft1, fft2, x, y, W); break;
            case 20: fwd0fftr<20>()(fft1, fft2, x, y, W); break;
            case 21: fwd0fftr<21>()(fft1, fft2, x, y, W); break;
            case 22: fwd0fftr<22>()(fft1, fft2, x, y, W); break;
            case 23: fwd0fftr<23>()(fft1, fft2, x, y, W); break;
            case 24: fwd0fftr<24>()(fft1, fft2, x, y, W); break;
        }
    }

    inline void fwdn(complex_vector x, complex_vector y) const { fwd(x, y); }

    inline void inv(complex_vector x, complex_vector y) const
    {
        switch (log_N) {
            case  0: break;
            case  1: fft1.inv0(x, y); break;
            case  2: inv0fftr< 2>()(fft1, fft2, x, y, W); break;
            case  3: inv0fftr< 3>()(fft1, fft2, x, y, W); break;
            case  4: inv0fftr< 4>()(fft1, fft2, x, y, W); break;
            case  5: inv0fftr< 5>()(fft1, fft2, x, y, W); break;
            case  6: inv0fftr< 6>()(fft1, fft2, x, y, W); break;
            case  7: inv0fftr< 7>()(fft1, fft2, x, y, W); break;
            case  8: inv0fftr< 8>()(fft1, fft2, x, y, W); break;
            case  9: inv0fftr< 9>()(fft1, fft2, x, y, W); break;
            case 10: inv0fftr<10>()(fft1, fft2, x, y, W); break;
            case 11: inv0fftr<11>()(fft1, fft2, x, y, W); break;
            case 12: inv0fftr<12>()(fft1, fft2, x, y, W); break;
            case 13: inv0fftr<13>()(fft1, fft2, x, y, W); break;
            case 14: inv0fftr<14>()(fft1, fft2, x, y, W); break;
            case 15: inv0fftr<15>()(fft1, fft2, x, y, W); break;
            case 16: inv0fftr<16>()(fft1, fft2, x, y, W); break;
            case 17: inv0fftr<17>()(fft1, fft2, x, y, W); break;
            case 18: inv0fftr<18>()(fft1, fft2, x, y, W); break;
            case 19: inv0fftr<19>()(fft1, fft2, x, y, W); break;
            case 20: inv0fftr<20>()(fft1, fft2, x, y, W); break;
            case 21: inv0fftr<21>()(fft1, fft2, x, y, W); break;
            case 22: inv0fftr<22>()(fft1, fft2, x, y, W); break;
            case 23: inv0fftr<23>()(fft1, fft2, x, y, W); break;
            case 24: inv0fftr<24>()(fft1, fft2, x, y, W); break;
        }
    }

    inline void inv0(complex_vector x, complex_vector y) const { inv(x, y); }

    inline void invn(complex_vector x, complex_vector y) const
    {
        switch (log_N) {
            case  0: break;
            case  1: fft1.invn(x, y); break;
            case  2: invnfftr< 2>()(fft1, fft2, x, y, W); break;
            case  3: invnfftr< 3>()(fft1, fft2, x, y, W); break;
            case  4: invnfftr< 4>()(fft1, fft2, x, y, W); break;
            case  5: invnfftr< 5>()(fft1, fft2, x, y, W); break;
            case  6: invnfftr< 6>()(fft1, fft2, x, y, W); break;
            case  7: invnfftr< 7>()(fft1, fft2, x, y, W); break;
            case  8: invnfftr< 8>()(fft1, fft2, x, y, W); break;
            case  9: invnfftr< 9>()(fft1, fft2, x, y, W); break;
            case 10: invnfftr<10>()(fft1, fft2, x, y, W); break;
            case 11: invnfftr<11>()(fft1, fft2, x, y, W); break;
            case 12: invnfftr<12>()(fft1, fft2, x, y, W); break;
            case 13: invnfftr<13>()(fft1, fft2, x, y, W); break;
            case 14: invnfftr<14>()(fft1, fft2, x, y, W); break;
            case 15: invnfftr<15>()(fft1, fft2, x, y, W); break;
            case 16: invnfftr<16>()(fft1, fft2, x, y, W); break;
            case 17: invnfftr<17>()(fft1, fft2, x, y, W); break;
            case 18: invnfftr<18>()(fft1, fft2, x, y, W); break;
            case 19: invnfftr<19>()(fft1, fft2, x, y, W); break;
            case 20: invnfftr<20>()(fft1, fft2, x, y, W); break;
            case 21: invnfftr<21>()(fft1, fft2, x, y, W); break;
            case 22: invnfftr<22>()(fft1, fft2, x, y, W); break;
            case 23: invnfftr<23>()(fft1, fft2, x, y, W); break;
            case 24: invnfftr<24>()(fft1, fft2, x, y, W); break;
        }
    }
};
#endif

#if 0
struct FFT
{
    FFT0 fft;
    simd_array<complex_t> work;
    complex_t* y;

    FFT() : fft(), work(), y(0) {}
    FFT(int n) : fft(n), work(n), y(&work) {}

    inline void setup(const int n) { fft.setup(n); work.setup(n); y = &work; }

    inline void fwd(complex_vector  x) const { fft.fwd(x, y);  }
    inline void fwd0(complex_vector x) const { fft.fwd0(x, y); }
    inline void fwdn(complex_vector x) const { fft.fwdn(x, y); }
    inline void inv(complex_vector  x) const { fft.inv(x, y);  }
    inline void inv0(complex_vector x) const { fft.inv0(x, y); }
    inline void invn(complex_vector x) const { fft.invn(x, y); }
};
#endif

} /////////////////////////////////////////////////////////////////////////////

#endif // otfft_sixstep_h
