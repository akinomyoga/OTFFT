/******************************************************************************
*  OTFFT Sixstep of Normalized Square Version 5.2
******************************************************************************/

#ifndef otfft_sixstepns_h
#define otfft_sixstepns_h

namespace OTFFT_Sixstep { /////////////////////////////////////////////////////

template <int log_N> struct fwdnffts
{
    static const int log_n = log_N/2;
    static const int N = 1 << log_N;
    static const int n = 1 << log_n;
    
    static inline void transpose_kernel(const int k, complex_vector x)
    {
        fwd0ffts_body<log_N,1>::transpose_kernel(k, x);
    }

    static void mult_twiddle_factor_kernel(
            const int p, complex_vector x, const_complex_vector W)
    {
        static const ymm rN = { 1.0/N, 1.0/N, 1.0/N, 1.0/N };
        const int pp = p*p;
        complex_vector x_p_pn = x + p + p*n;
        const complex_t& w = W[pp+p];
        const ymm w1 = mulpd2(rN, cmplx2(W[pp], w));
        const ymm w2 = mulpd2(rN, cmplx2(w, W[pp+2*p+1]));
        const ymm ab = getpz2(x_p_pn+0);
        const ymm cd = getpz2(x_p_pn+n);
        const ymm ac = mulpz2(w1, catlo(ab, cd));
        const ymm bd = mulpz2(w2, cathi(ab, cd));
        setpz2(x_p_pn+0, ac);
        setpz2(x_p_pn+n, bd);
        for (int k = p+2; k < n; k += 2) {
            const int kp = k*p;
            complex_vector x_k_pn = x + k + p*n;
            complex_vector x_p_kn = x + p + k*n;
            const ymm w1 = mulpd2(rN, cmplx2(W[kp],   W[kp+k]));
            const ymm w2 = mulpd2(rN, cmplx2(W[kp+p], W[kp+k+p+1]));
            const ymm ab = getpz2(x_k_pn+0);
            const ymm cd = getpz2(x_k_pn+n);
            const ymm ac = mulpz2(w1, catlo(ab, cd));
            const ymm bd = mulpz2(w2, cathi(ab, cd));
            const ymm ef = mulpz2(w1, getpz2(x_p_kn+0));
            const ymm gh = mulpz2(w2, getpz2(x_p_kn+n));
            const ymm eg = catlo(ef, gh);
            const ymm fh = cathi(ef, gh);
            setpz2(x_p_kn+0, ac);
            setpz2(x_p_kn+n, bd);
            setpz2(x_k_pn+0, eg);
            setpz2(x_k_pn+n, fh);
        }
    }

    template <typename fft_t>
    void operator()(const fft_t& fft,
            complex_vector x, complex_vector y, const_complex_vector W) const
    {
        if (N < OMP_THRESHOLD1) {
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                fft.fwd0(x + pn, y + pn);
            }
            for (int p = 0; p < n; p += 2) {
                mult_twiddle_factor_kernel(p, x, W);
            }
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                fft.fwd0(x + kn, y + kn);
            }
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
        }
        else if (N < OMP_THRESHOLD2) //////////////////////////////////////////
        #pragma omp parallel
        {
            #pragma omp for schedule(static)
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
            #pragma omp for schedule(static)
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                fft.fwd0(x + pn, y + pn);
            }
            #pragma omp for schedule(static)
            for (int p = 0; p < n; p += 2) {
                mult_twiddle_factor_kernel(p, x, W);
            }
            #pragma omp for schedule(static)
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                fft.fwd0(x + kn, y + kn);
            }
            #pragma omp for schedule(static) nowait
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
        }
        else //////////////////////////////////////////////////////////////////
        #pragma omp parallel
        {
            #pragma omp for schedule(guided)
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
            #pragma omp for schedule(guided)
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                fft.fwd0(x + pn, y + pn);
            }
            #pragma omp for schedule(guided)
            for (int p = 0; p < n; p += 2) {
                mult_twiddle_factor_kernel(p, x, W);
            }
            #pragma omp for schedule(guided)
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                fft.fwd0(x + kn, y + kn);
            }
            #pragma omp for schedule(guided) nowait
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
        }
    }
};

///////////////////////////////////////////////////////////////////////////////

template <int log_N> struct invnffts
{
    static const int log_n = log_N/2;
    static const int N = 1 << log_N;
    static const int n = 1 << log_n;
    
    static inline void transpose_kernel(const int k, complex_vector x)
    {
        fwdnffts<log_N>::transpose_kernel(k, x);
    }

    static void mult_twiddle_factor_kernel(
            const int p, complex_vector x, const_complex_vector W)
    {
        static const ymm rN = { 1.0/N, 1.0/N, 1.0/N, 1.0/N };
        const int pp = p*p;
        complex_vector x_p_pn = x + p + p*n;
        const complex_t& w = W[N-pp-p];
        const ymm w1 = mulpd2(rN, cmplx2(W[N-pp], w));
        const ymm w2 = mulpd2(rN, cmplx2(w, W[N-pp-2*p-1]));
        const ymm ab = getpz2(x_p_pn+0);
        const ymm cd = getpz2(x_p_pn+n);
        const ymm ac = mulpz2(w1, catlo(ab, cd));
        const ymm bd = mulpz2(w2, cathi(ab, cd));
        setpz2(x_p_pn+0, ac);
        setpz2(x_p_pn+n, bd);
        for (int k = p+2; k < n; k += 2) {
            const int kp = k*p;
            complex_vector x_k_pn = x + k + p*n;
            complex_vector x_p_kn = x + p + k*n;
            const ymm w1 = mulpd2(rN, cmplx2(W[N-kp],   W[N-kp-k]));
            const ymm w2 = mulpd2(rN, cmplx2(W[N-kp-p], W[N-kp-k-p-1]));
            const ymm ab = getpz2(x_k_pn+0);
            const ymm cd = getpz2(x_k_pn+n);
            const ymm ac = mulpz2(w1, catlo(ab, cd));
            const ymm bd = mulpz2(w2, cathi(ab, cd));
            const ymm ef = mulpz2(w1, getpz2(x_p_kn+0));
            const ymm gh = mulpz2(w2, getpz2(x_p_kn+n));
            const ymm eg = catlo(ef, gh);
            const ymm fh = cathi(ef, gh);
            setpz2(x_p_kn+0, ac);
            setpz2(x_p_kn+n, bd);
            setpz2(x_k_pn+0, eg);
            setpz2(x_k_pn+n, fh);
        }
    }

    template <typename fft_t>
    void operator()(const fft_t& fft,
            complex_vector x, complex_vector y, const_complex_vector W) const
    {
        if (N < OMP_THRESHOLD1) {
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                fft.inv0(x + pn, y + pn);
            }
            for (int p = 0; p < n; p += 2) {
                mult_twiddle_factor_kernel(p, x, W);
            }
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                fft.inv0(x + kn, y + kn);
            }
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
        }
        else if (N < OMP_THRESHOLD2) //////////////////////////////////////////
        #pragma omp parallel
        {
            #pragma omp for schedule(static)
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
            #pragma omp for schedule(static)
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                fft.inv0(x + pn, y + pn);
            }
            #pragma omp for schedule(static)
            for (int p = 0; p < n; p += 2) {
                mult_twiddle_factor_kernel(p, x, W);
            }
            #pragma omp for schedule(static)
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                fft.inv0(x + kn, y + kn);
            }
            #pragma omp for schedule(static) nowait
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
        }
        else //////////////////////////////////////////////////////////////////
        #pragma omp parallel
        {
            #pragma omp for schedule(guided)
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
            #pragma omp for schedule(guided)
            for (int p = 0; p < n; p++) {
                const int pn = p*n;
                fft.inv0(x + pn, y + pn);
            }
            #pragma omp for schedule(guided)
            for (int p = 0; p < n; p += 2) {
                mult_twiddle_factor_kernel(p, x, W);
            }
            #pragma omp for schedule(guided)
            for (int k = 0; k < n; k++) {
                const int kn = k*n;
                fft.inv0(x + kn, y + kn);
            }
            #pragma omp for schedule(guided) nowait
            for (int k = 0; k < n; k += 2) {
                transpose_kernel(k, x);
            }
        }
    }
};

} /////////////////////////////////////////////////////////////////////////////

#endif // otfft_sixstepns_h
