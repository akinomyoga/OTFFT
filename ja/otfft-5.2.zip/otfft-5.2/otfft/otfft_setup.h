switch (log_N) {
case  0: break;
case  1: fft1->setup2(log_N); break;
case  2: fft3->setup2(log_N); break;
case  3: fft3->setup2(log_N); break;
case  4: fft2->setup2(log_N); break;
case  5: fft4->setup2(log_N); break;
case  6: fft2->setup2(log_N); break;
case  7: fft2->setup2(log_N); break;
case  8: fft2->setup2(log_N); break;
case  9: fft1->setup2(log_N); break;
case 10: fft1->setup2(log_N); break;
case 11: fft1->setup2(log_N); break;
case 12: fft1->setup2(log_N); break;
case 13: fft3->setup2(log_N); break;
case 14: fft3->setup2(log_N); break;
case 15: fft4->setup2(log_N); break;
case 16: fft1->setup2(log_N); break;
case 17: fft4->setup2(log_N); break;
case 18: fft5->setup2(log_N); break;
case 19: fft5->setup2(log_N); break;
case 20: fft5->setup2(log_N); break;
case 21: fft3->setup2(log_N); break;
default: fft5->setup2(log_N); break;
}
