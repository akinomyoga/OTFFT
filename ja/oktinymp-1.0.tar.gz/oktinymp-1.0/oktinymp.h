/******************************************************************************
*  OktinyMP Version 1.0
*
*  Copyright (c) 2016 OK Ojisan(Takuya OKAHISA)
*  Released under the MIT license
*  http://opensource.org/licenses/mit-license.php
******************************************************************************/

#ifndef oktinymp_h
#define oktinymp_h

#include <chrono>
#include <atomic>
#include <vector>
#include <thread>
#include <functional>
#include <mutex>

namespace OktinyMP {

template <int TSLEEP> struct usleep_for
{
    inline void operator()() const noexcept
    {
        std::this_thread::sleep_for(std::chrono::microseconds(TSLEEP));
    }
};
template <> struct usleep_for<0>
{
    inline void operator()() const noexcept {}
};

template <int TSLEEP> class Trigger
{
    const int n;
    std::atomic<int> counter1 {0};

    public:
    Trigger(const int n) noexcept: n(n) {}
    Trigger(const Trigger&) = delete;
    Trigger& operator=(const Trigger&) = delete;

    void wait() noexcept
    {
        counter1++;
        while (counter1 > 0) usleep_for<TSLEEP>()();
    }

    void start() noexcept
    {
        while (counter1 < n-1) usleep_for<TSLEEP>()();
        counter1 = 0;
    }
};

template <int TSLEEP> class Barrier
{
    const int n;
    std::atomic<int> counter {0};
    std::atomic<bool> x {false};

    public:
    Barrier(const int n) noexcept: n(n) {}
    Barrier(const Barrier&) = delete;
    Barrier& operator=(const Barrier&) = delete;

    void wait() noexcept
    {
        const bool y = !x;
        if (++counter < n) while (x != y) usleep_for<TSLEEP>()();
        else { counter = 0; x = y; }
    }
};

template <int TSLEEP> class Starter
{
    const int n;
    Trigger<TSLEEP> trigger;
    Barrier<TSLEEP> barrier;
    std::vector<std::thread> tg;
    const std::function<void(const int)>* fp;
    std::atomic<bool> done {true};
    std::mutex mtx;
    thread_local static int tid;
    static int ncores;

    public:
    Starter(): n(get_concurrency()), trigger(n), barrier(n) { ncores = n; }
    Starter(const Starter&) = delete;
    Starter& operator=(const Starter&) = delete;
    ~Starter() { join(); }

    void fork()
    {
        if (!done) return;
        done = false;
        tg.clear();
        for (int id = 1; id < n; id++) {
            const auto loop = [&,id]() noexcept {
                tid = id;
                for (;;) {
                    trigger.wait();
                    if (done) break;
                    (*fp)(id);
                    barrier.wait();
                }
            };
            tg.push_back(std::thread(loop));
        }
    }

    void go(const std::function<void(int)>& code) noexcept
    {
        if (done) {
            for (auto& t : tg) t.join();
            fork();
        }
        fp = &code; 
        trigger.start();
        code(0);
        barrier.wait();
    }

    void join()
    {
        if (!done) { done = true; trigger.start(); }
        for (auto& t : tg) t.join();
        tg.clear();
    }

    inline void wait() noexcept { barrier.wait(); }

    inline void critical(const std::function<void()>& code)
    {
        std::lock_guard<std::mutex> lck(mtx);
        code();
    }

#ifdef _MSC_VER
    static inline int get_concurrency() noexcept
    {
        if (ncores > 0) return ncores;
        char* value = 0; size_t sz = 0;
        if (_dupenv_s(&value, &sz, "OKT_NUM_THREADS") == 0) {
            if (value) {
                const int n = atoi(value);
                free(value);
                return n;
            }
        }
        return std::thread::hardware_concurrency();
    }
#else
    static inline int get_concurrency() noexcept
    {
        const char* value = getenv("OKT_NUM_THREADS");
        return ncores > 0 ? ncores :
            value ? atoi(value) : std::thread::hardware_concurrency();
    }
#endif

    static inline int get_id() noexcept { return tid; }

    static inline int i0(const int N) noexcept
    {
        typedef long long ll;
        return static_cast<int>(ll(N)*ll(tid)/ncores);
    }

    static inline int iN(const int N) noexcept
    {
        typedef long long ll;
        return static_cast<int>(ll(N)*ll(tid+1)/ncores);
    }
};

template <int TSLEEP> thread_local int Starter<TSLEEP>::tid = 0;
template <int TSLEEP> int Starter<TSLEEP>::ncores = 0;

} // namespace OktinyMP

#endif // oktinymp_h
