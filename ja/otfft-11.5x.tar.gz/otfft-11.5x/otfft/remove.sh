#!/bin/sh -

rm otfft_gen_*.h
