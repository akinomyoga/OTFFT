#!/bin/sh -

cp backup/otfft_gen_*.h .
