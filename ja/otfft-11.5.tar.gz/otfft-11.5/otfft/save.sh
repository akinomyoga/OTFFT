#!/bin/sh -

cp otfft_gen_*.h backup
