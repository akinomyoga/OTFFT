switch (log_N) {
case  0: break;
case  1: obj = new FFT3(sr); break;
case  2: obj = new FFT7(sr); break;
case  3: obj = new FFT7(sr); break;
case  4: obj = new FFT2(sr); break;
case  5: obj = new FFT3(sr); break;
case  6: obj = new FFT1(sr); break;
case  7: obj = new FFT1(sr); break;
case  8: obj = new FFT1(sr); break;
case  9: obj = new FFT1(sr); break;
case 10: obj = new FFT5(sr); break;
case 11: obj = new FFT6(sr); break;
case 12: obj = new FFT6(sr); break;
case 13: obj = new FFT5(sr); break;
case 14: obj = new FFT3(sr); break;
case 15: obj = new FFT3(sr); break;
case 16: obj = new FFT6(sr); break;
case 17: obj = new FFT4(sr); break;
case 18: obj = new FFT6(sr); break;
case 19: obj = new FFT6(sr); break;
case 20: obj = new FFT7(sr); break;
case 21: obj = new FFT4(sr); break;
case 22: obj = new FFT7(sr); break;
case 23: obj = new FFT7(sr); break;
case 24: obj = new FFT7(sr); break;
default: obj = new FFT8(sr); break;
}
