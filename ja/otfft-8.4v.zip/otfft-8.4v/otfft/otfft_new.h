switch (log_N) {
case  0: break;
case  1: obj = new FFT7(); break;
case  2: obj = new FFT1(); break;
case  3: obj = new FFT3(); break;
case  4: obj = new FFT2(); break;
case  5: obj = new FFT3(); break;
case  6: obj = new FFT3(); break;
case  7: obj = new FFT6(); break;
case  8: obj = new FFT3(); break;
case  9: obj = new FFT3(); break;
case 10: obj = new FFT1(); break;
case 11: obj = new FFT6(); break;
case 12: obj = new FFT6(); break;
case 13: obj = new FFT6(); break;
case 14: obj = new FFT6(); break;
case 15: obj = new FFT6(); break;
case 16: obj = new FFT6(); break;
case 17: obj = new FFT4(); break;
case 18: obj = new FFT7(); break;
case 19: obj = new FFT5(); break;
case 20: obj = new FFT6(); break;
case 21: obj = new FFT5(); break;
case 22: obj = new FFT6(); break;
case 23: obj = new FFT6(); break;
case 24: obj = new FFT6(); break;
default: obj = new FFT8(); break;
}
