switch (log_N) {
case  0: break;
case  1: fft5->invn(x, y); break;
case  2: fft5->invn(x, y); break;
case  3: fft5->invn(x, y); break;
case  4: fft2->invn(x, y); break;
case  5: fft4->invn(x, y); break;
case  6: fft1->invn(x, y); break;
case  7: fft1->invn(x, y); break;
case  8: fft1->invn(x, y); break;
case  9: fft1->invn(x, y); break;
case 10: fft1->invn(x, y); break;
case 11: fft7->invn(x, y); break;
case 12: fft7->invn(x, y); break;
case 13: fft6->invn(x, y); break;
case 14: fft3->invn(x, y); break;
case 15: fft4->invn(x, y); break;
case 16: fft7->invn(x, y); break;
case 17: fft4->invn(x, y); break;
case 18: fft7->invn(x, y); break;
case 19: fft5->invn(x, y); break;
case 20: fft5->invn(x, y); break;
case 21: fft4->invn(x, y); break;
default: fft5->invn(x, y); break;
}
