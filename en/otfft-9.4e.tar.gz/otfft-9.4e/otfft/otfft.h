/******************************************************************************
*  OTFFT Header Version 9.4
*
*  Copyright (c) 2015 OK Ojisan(Takuya OKAHISA)
*  Released under the MIT license
*  http://opensource.org/licenses/mit-license.php
******************************************************************************/

#ifndef otfft_h
#define otfft_h

#ifdef __cplusplus

#include <cmath>
#include "otfft_misc.h"

namespace OTFFT_AVXDIF4 { struct FFT0; }
namespace OTFFT_AVXDIT4 { struct FFT0; }
namespace OTFFT_AVXDIF8 { struct FFT0; }
namespace OTFFT_AVXDIT8 { struct FFT0; }
namespace OTFFT_AVXDIF16 { struct FFT0; }
namespace OTFFT_AVXDIT16 { struct FFT0; }
namespace OTFFT_Sixstep { struct FFT0; }
namespace OTFFT_MixedRadix { struct FFT0; }

namespace OTFFT { /////////////////////////////////////////////////////////////

using namespace OTFFT_MISC;

typedef OTFFT_AVXDIF4::FFT0 FFT1;
typedef OTFFT_AVXDIT4::FFT0 FFT2;
typedef OTFFT_AVXDIF8::FFT0 FFT3;
typedef OTFFT_AVXDIT8::FFT0 FFT4;
typedef OTFFT_AVXDIF16::FFT0 FFT5;
typedef OTFFT_AVXDIT16::FFT0 FFT6;
typedef OTFFT_Sixstep::FFT0 FFT7;
typedef OTFFT_MixedRadix::FFT0 FFT8;

/******************************************************************************
*  Complex FFT
******************************************************************************/

struct FFT0
{
    void* obj;
    int N, log_N;

    FFT0() NOEXCEPT;
    FFT0(int n);
    ~FFT0() NOEXCEPT;

    void setup(int n);

    void fwd(complex_vector  x, complex_vector y) const NOEXCEPT;
    void fwd0(complex_vector x, complex_vector y) const NOEXCEPT;
    void fwdu(complex_vector x, complex_vector y) const NOEXCEPT;
    void fwdn(complex_vector x, complex_vector y) const NOEXCEPT;
    void inv(complex_vector  x, complex_vector y) const NOEXCEPT;
    void inv0(complex_vector x, complex_vector y) const NOEXCEPT;
    void invu(complex_vector x, complex_vector y) const NOEXCEPT;
    void invn(complex_vector x, complex_vector y) const NOEXCEPT;
};

struct FFT
{
    FFT0 fft;
    simd_array<complex_t> work;
    complex_t* y;

    FFT() NOEXCEPT : fft(), work(), y(0) {}
    FFT(int n) : fft(n), work(n), y(&work) {}

    inline void setup(int n) { fft.setup(n); work.setup(n); y = &work; }

    inline void fwd(complex_vector  x) const NOEXCEPT { fft.fwd(x, y);  }
    inline void fwd0(complex_vector x) const NOEXCEPT { fft.fwd0(x, y); }
    inline void fwdu(complex_vector x) const NOEXCEPT { fft.fwdu(x, y); }
    inline void fwdn(complex_vector x) const NOEXCEPT { fft.fwdn(x, y); }
    inline void inv(complex_vector  x) const NOEXCEPT { fft.inv(x, y);  }
    inline void inv0(complex_vector x) const NOEXCEPT { fft.inv0(x, y); }
    inline void invu(complex_vector x) const NOEXCEPT { fft.invu(x, y); }
    inline void invn(complex_vector x) const NOEXCEPT { fft.invn(x, y); }
};

/******************************************************************************
*  Real FFT
******************************************************************************/

struct RFFT
{
#ifdef DO_SINGLE_THREAD
    static const int OMP_THRESHOLD   = 1<<30;
    static const int OMP_THRESHOLD_W = 1<<30;
#else
    static const int OMP_THRESHOLD   = 1<<15;
    static const int OMP_THRESHOLD_W = 1<<16;
#endif

    int N;
    FFT0 fft;
    simd_array<complex_t> weight;
    complex_t* U;

    RFFT();
    RFFT(int n);

    void setup(int n);

    void fwd(const_double_vector  x, complex_vector y) const NOEXCEPT;
    void fwd0(const_double_vector x, complex_vector y) const NOEXCEPT;
    void fwdu(const_double_vector x, complex_vector y) const NOEXCEPT;
    void fwdn(const_double_vector x, complex_vector y) const NOEXCEPT;
    void inv(complex_vector  x, double_vector y) const NOEXCEPT;
    void inv0(complex_vector x, double_vector y) const NOEXCEPT;
    void invu(complex_vector x, double_vector y) const NOEXCEPT;
    void invn(complex_vector x, double_vector y) const NOEXCEPT;
};

/******************************************************************************
*  DCT
******************************************************************************/

struct DCT0
{
#ifdef DO_SINGLE_THREAD
    static const int OMP_THRESHOLD   = 1<<30;
    static const int OMP_THRESHOLD_W = 1<<30;
#else
    static const int OMP_THRESHOLD   = 1<<15;
    static const int OMP_THRESHOLD_W = 1<<16;
#endif

    int N;
    RFFT rfft;
    simd_array<complex_t> weight;
    complex_t* V;

    DCT0();
    DCT0(int n);

    void setup(int n);

    void fwd(double_vector  x, double_vector y, complex_vector z) const NOEXCEPT;
    void fwd0(double_vector x, double_vector y, complex_vector z) const NOEXCEPT;
    void fwdn(double_vector x, double_vector y, complex_vector z) const NOEXCEPT;
    void inv(double_vector  x, double_vector y, complex_vector z) const NOEXCEPT;
    void inv0(double_vector x, double_vector y, complex_vector z) const NOEXCEPT;
    void invn(double_vector x, double_vector y, complex_vector z) const NOEXCEPT;
};

struct DCT
{
    int N;
    DCT0 dct;
    simd_array<double> work1;
    simd_array<complex_t> work2;
    double* y;
    complex_t* z;

    DCT() : N(0), y(0), z(0) {}
    DCT(int n) { setup(n); }

    void setup(int n)
    {
        N = n;
        dct.setup(N);
        work1.setup(N); y = &work1;
        work2.setup(N); z = &work2;
    }

    void fwd(double_vector  x) const NOEXCEPT { dct.fwd(x, y, z);  }
    void fwd0(double_vector x) const NOEXCEPT { dct.fwd0(x, y, z); }
    void fwdn(double_vector x) const NOEXCEPT { dct.fwdn(x, y, z); }
    void inv(double_vector  x) const NOEXCEPT { dct.inv(x, y, z);  }
    void inv0(double_vector x) const NOEXCEPT { dct.inv0(x, y, z); }
    void invn(double_vector x) const NOEXCEPT { dct.invn(x, y, z); }
};

/******************************************************************************
*  Bluestein's FFT
******************************************************************************/

struct Bluestein
{
#ifdef DO_SINGLE_THREAD
    static const int OMP_THRESHOLD   = 1<<30;
    static const int OMP_THRESHOLD_W = 1<<30;
#else
    static const int OMP_THRESHOLD   = 1<<15;
    static const int OMP_THRESHOLD_W = 1<<16;
#endif

    int N, L;
    FFT fft;
    simd_array<complex_t> work1;
    simd_array<complex_t> work2;
    simd_array<complex_t> weight;
    complex_t* a;
    complex_t* b;
    complex_t* W;

    Bluestein();
    Bluestein(int n);

    void setup(int n);

    void fwd(complex_vector  x) const NOEXCEPT;
    void fwd0(complex_vector x) const NOEXCEPT;
    void fwdu(complex_vector x) const NOEXCEPT;
    void fwdn(complex_vector x) const NOEXCEPT;
    void inv(complex_vector  x) const NOEXCEPT;
    void inv0(complex_vector x) const NOEXCEPT;
    void invu(complex_vector x) const NOEXCEPT;
    void invn(complex_vector x) const NOEXCEPT;
};

} /////////////////////////////////////////////////////////////////////////////

#else
#include "otfft_c.h"
#endif // __cplusplus

#endif // otfft_h
